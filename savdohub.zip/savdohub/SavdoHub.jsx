import { useState, useEffect, useRef } from "react";

// ============================================================
// DATA & CONSTANTS
// ============================================================
const CATEGORIES = [
  { id: "electronics", name: "Электроника", icon: "📱", color: "#3B82F6" },
  { id: "clothing", name: "Либос", icon: "👗", color: "#EC4899" },
  { id: "home", name: "Хона", icon: "🏠", color: "#10B981" },
  { id: "toys", name: "Бозичаҳо", icon: "🧸", color: "#F59E0B" },
  { id: "auto", name: "Авто", icon: "🚗", color: "#6366F1" },
  { id: "food", name: "Ғизо", icon: "🍎", color: "#EF4444" },
  { id: "sports", name: "Варзиш", icon: "⚽", color: "#14B8A6" },
  { id: "other", name: "Дигар", icon: "📦", color: "#8B5CF6" },
];

const PRODUCTS = [
  { id: 1, name: "iPhone 15 Pro Max", price: 8500, originalPrice: 9200, category: "electronics", shopId: 1, rating: 4.8, reviews: 234, stock: 15, weight: 0.2, image: "📱", description: "Смартфони iPhone 15 Pro Max бо тактикаи титаниум, камераи 48MP ва чипи A17 Pro.", badge: "ТОП", video: true },
  { id: 2, name: "Куртаи занона", price: 180, originalPrice: 250, category: "clothing", shopId: 2, rating: 4.5, reviews: 89, stock: 50, weight: 0.3, image: "👗", description: "Куртаи занона аз матои сифатноки турецкӣ, андозаҳои S-XXL.", badge: "НАРХ ПАСТ", video: false },
  { id: 3, name: 'Телевизор Samsung 55"', price: 4200, originalPrice: 4800, category: "electronics", shopId: 1, rating: 4.7, reviews: 156, stock: 8, weight: 15, image: "📺", description: "Телевизори Smart Samsung бо экрани 4K UHD ва HDR.", badge: "МАЪМУЛ", video: true },
  { id: 4, name: "Диван кунҷӣ", price: 2800, originalPrice: 3500, category: "home", shopId: 3, rating: 4.6, reviews: 67, stock: 5, weight: 45, image: "🛋️", description: "Диван кунҷии муосир аз кожа барои хонаи шумо.", badge: null, video: false },
  { id: 5, name: "Велосипеди кӯдакона", price: 450, originalPrice: 550, category: "toys", shopId: 4, rating: 4.9, reviews: 312, stock: 23, weight: 8, image: "🚲", description: "Велосипеди кӯдакона барои синнусоли 5-10, бехатар ва пойдор.", badge: "БЕСТСЕЛЛЕР", video: false },
  { id: 6, name: "Кофемашина DeLonghi", price: 1200, originalPrice: 1400, category: "home", shopId: 3, rating: 4.4, reviews: 98, stock: 12, weight: 4, image: "☕", description: "Кофемашинаи автоматии DeLonghi барои қаҳва дар хона.", badge: null, video: true },
  { id: 7, name: "Тренерка Adidas", price: 320, originalPrice: 420, category: "sports", shopId: 5, rating: 4.6, reviews: 178, stock: 35, weight: 0.5, image: "👟", description: "Тренеркаи Adidas барои давидан ва варзиш.", badge: "НАРХ ПАСТ", video: false },
  { id: 8, name: "MacBook Air M2", price: 9800, originalPrice: 10500, category: "electronics", shopId: 1, rating: 4.9, reviews: 445, stock: 6, weight: 1.2, image: "💻", description: "MacBook Air бо чипи M2, батареяи 18 соата.", badge: "VIP", video: true },
  { id: 9, name: "Мошини бачагона", price: 85, originalPrice: 120, category: "toys", shopId: 4, rating: 4.3, reviews: 56, stock: 100, weight: 0.4, image: "🏎️", description: "Мошини радиоидоракунандаи бачагона.", badge: null, video: false },
  { id: 10, name: "Либоси спортии мардона", price: 145, originalPrice: 190, category: "clothing", shopId: 2, rating: 4.5, reviews: 123, stock: 60, weight: 0.6, image: "🧥", description: "Либоси спортии муосир барои мардон.", badge: null, video: false },
  { id: 11, name: "Bugatti Chiron Scale", price: 250, originalPrice: 320, category: "auto", shopId: 6, rating: 4.7, reviews: 45, stock: 10, weight: 1.5, image: "🚗", description: "Моделли масштабии автомобили Bugatti 1:18.", badge: null, video: true },
  { id: 12, name: "Яблуки тоза", price: 12, originalPrice: 15, category: "food", shopId: 7, rating: 4.8, reviews: 890, stock: 500, weight: 1, image: "🍎", description: "Яблуки тоза аз боғи Вахш, 1кг.", badge: "ТОЗА", video: false },
];

const SHOPS = [
  { id: 1, name: "TechHub Dushanbe", logo: "🏪", rating: 4.8, products: 89, plan: "premium", followers: 2340, city: "Душанбе", verified: true, description: "Беҳтарин электроника дар Тоҷикистон", featured: true },
  { id: 2, name: "Fashion Palace", logo: "👒", rating: 4.5, products: 234, plan: "premium", followers: 1567, city: "Душанбе", verified: true, description: "Либосҳои муосир барои ҳама", featured: true },
  { id: 3, name: "Уютный Дом", logo: "🏡", rating: 4.6, products: 67, plan: "standard", followers: 890, city: "Хуҷанд", verified: true, description: "Мебел ва лавозимоти хона", featured: false },
  { id: 4, name: "Toys World", logo: "🎠", rating: 4.9, products: 145, plan: "premium", followers: 3210, city: "Душанбе", verified: true, description: "Бозичаҳо барои кӯдакони шод", featured: true },
  { id: 5, name: "Sport Life", logo: "💪", rating: 4.7, products: 56, plan: "standard", followers: 678, city: "Кӯлоб", verified: false, description: "Лавозимоти варзишӣ", featured: false },
  { id: 6, name: "Auto Parts TJ", logo: "🔧", rating: 4.4, products: 312, plan: "basic", followers: 456, city: "Хуҷанд", verified: false, description: "Эҳтиёт қисмҳои автомобил", featured: false },
  { id: 7, name: "Organic Farm", logo: "🌿", rating: 4.9, products: 23, plan: "basic", followers: 1234, city: "Вахш", verified: true, description: "Маҳсулоти органикии тоза", featured: false },
];

const ORDERS = [
  { id: "SH-2024-001", product: "iPhone 15 Pro Max", status: "delivered", date: "2024-11-15", total: 8500, icon: "📱" },
  { id: "SH-2024-002", product: "Куртаи занона", status: "shipped", date: "2024-11-20", total: 180, icon: "👗" },
  { id: "SH-2024-003", product: "Велосипеди кӯдакона", status: "processing", date: "2024-11-22", total: 450, icon: "🚲" },
  { id: "SH-2024-004", product: "MacBook Air M2", status: "ordered", date: "2024-11-23", total: 9800, icon: "💻" },
];

const DELIVERY_PRICES = [
  { weight: "то 1кг", price: 15, icon: "📦" },
  { weight: "1–3кг", price: 25, icon: "📦" },
  { weight: "3–5кг", price: 35, icon: "📦" },
  { weight: "5кг+", price: 50, icon: "🚚" },
];

const PLANS = [
  { id: "basic", name: "Базавӣ", price: 29, color: "#6B7280", products: 20, features: ["то 20 маҳсулот", "Намоиши маъмулӣ", "Дастгирии асосӣ"] },
  { id: "standard", name: "Стандартӣ", price: 89, color: "#3B82F6", products: 100, features: ["то 100 маҳсулот", "Намоиши беҳтар", "Дастгирии афзалиятнок", "Видеоҳои маҳсулот"] },
  { id: "premium", name: "Премиум", price: 199, color: "#F59E0B", products: Infinity, features: ["Маҳсулоти беҳудуд", "Намоиш дар саҳифаи аввал", "Дастгирии VIP 24/7", "Видеоҳо + Реклама", "Аналитика пурра"] },
];

// ============================================================
// UTILITY FUNCTIONS
// ============================================================
const formatPrice = (p) => `${p.toLocaleString("ru-TJ")} сом.`;
const getShop = (id) => SHOPS.find((s) => s.id === id);
const getProduct = (id) => PRODUCTS.find((p) => p.id === id);

const getStatusLabel = (s) => ({ ordered: "Фармоиш дода шуд", processing: "Коркард мешавад", shipped: "Равона шуд", delivered: "Расид" }[s]);
const getStatusColor = (s) => ({ ordered: "#6B7280", processing: "#F59E0B", shipped: "#3B82F6", delivered: "#10B981" }[s]);

// ============================================================
// MICRO COMPONENTS
// ============================================================
const Badge = ({ text, color = "#F59E0B" }) => (
  <span style={{ background: color, color: "#fff", fontSize: 10, fontWeight: 700, padding: "2px 7px", borderRadius: 20, letterSpacing: 0.5 }}>{text}</span>
);

const Stars = ({ rating, size = 12 }) => (
  <span style={{ fontSize: size, color: "#F59E0B" }}>{"★".repeat(Math.round(rating))}{"☆".repeat(5 - Math.round(rating))}</span>
);

const Btn = ({ children, onClick, variant = "primary", style = {}, disabled = false }) => {
  const styles = {
    primary: { background: "linear-gradient(135deg, #FF6B35, #FF4500)", color: "#fff" },
    secondary: { background: "#F3F4F6", color: "#374151" },
    outline: { background: "transparent", border: "1.5px solid #FF6B35", color: "#FF6B35" },
    green: { background: "linear-gradient(135deg, #10B981, #059669)", color: "#fff" },
    ghost: { background: "transparent", color: "#6B7280" },
  };
  return (
    <button onClick={onClick} disabled={disabled} style={{ ...styles[variant], border: "none", borderRadius: 12, padding: "10px 18px", fontWeight: 700, fontSize: 13, cursor: disabled ? "not-allowed" : "pointer", opacity: disabled ? 0.6 : 1, transition: "all 0.2s", fontFamily: "inherit", ...style }}>
      {children}
    </button>
  );
};

const Avatar = ({ emoji, size = 40, bg = "#FFF3E0" }) => (
  <div style={{ width: size, height: size, borderRadius: "50%", background: bg, display: "flex", alignItems: "center", justifyContent: "center", fontSize: size * 0.45, flexShrink: 0 }}>{emoji}</div>
);

const Tag = ({ children, color = "#EFF6FF", textColor = "#3B82F6" }) => (
  <span style={{ background: color, color: textColor, fontSize: 11, fontWeight: 600, padding: "3px 9px", borderRadius: 20 }}>{children}</span>
);

// ============================================================
// PRODUCT CARD
// ============================================================
const ProductCard = ({ product, onOpen, onAddCart, compact = false }) => {
  const [liked, setLiked] = useState(false);
  const shop = getShop(product.shopId);
  const disc = product.originalPrice ? Math.round((1 - product.price / product.originalPrice) * 100) : 0;

  return (
    <div onClick={() => onOpen(product)} style={{ background: "#fff", borderRadius: 16, overflow: "hidden", boxShadow: "0 2px 12px rgba(0,0,0,0.07)", cursor: "pointer", transition: "transform 0.2s, box-shadow 0.2s", position: "relative" }}
      onMouseEnter={e => { e.currentTarget.style.transform = "translateY(-3px)"; e.currentTarget.style.boxShadow = "0 8px 24px rgba(0,0,0,0.12)"; }}
      onMouseLeave={e => { e.currentTarget.style.transform = ""; e.currentTarget.style.boxShadow = "0 2px 12px rgba(0,0,0,0.07)"; }}>
      {/* Image */}
      <div style={{ height: compact ? 110 : 140, background: "linear-gradient(135deg, #FFF8F0, #FFEFDF)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: compact ? 50 : 64, position: "relative" }}>
        {product.image}
        {product.video && <div style={{ position: "absolute", bottom: 8, right: 8, background: "rgba(0,0,0,0.6)", borderRadius: 20, padding: "2px 8px", color: "#fff", fontSize: 10, fontWeight: 700 }}>▶ ВИДЕО</div>}
        {disc > 0 && <div style={{ position: "absolute", top: 8, left: 8, background: "#EF4444", color: "#fff", borderRadius: 20, padding: "2px 8px", fontSize: 11, fontWeight: 700 }}>-{disc}%</div>}
        <button onClick={e => { e.stopPropagation(); setLiked(!liked); }} style={{ position: "absolute", top: 8, right: 8, background: "#fff", border: "none", borderRadius: "50%", width: 30, height: 30, cursor: "pointer", fontSize: 14, boxShadow: "0 2px 8px rgba(0,0,0,0.15)" }}>
          {liked ? "❤️" : "🤍"}
        </button>
        {product.badge && <div style={{ position: "absolute", bottom: 8, left: 8 }}><Badge text={product.badge} color={product.badge === "VIP" ? "#8B5CF6" : product.badge === "БЕСТСЕЛЛЕР" ? "#EF4444" : "#F59E0B"} /></div>}
      </div>
      {/* Info */}
      <div style={{ padding: compact ? "10px" : "12px" }}>
        <div style={{ fontSize: compact ? 12 : 13, fontWeight: 600, color: "#1F2937", marginBottom: 4, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{product.name}</div>
        <div style={{ display: "flex", alignItems: "center", gap: 4, marginBottom: 6 }}>
          <Stars rating={product.rating} size={10} />
          <span style={{ fontSize: 10, color: "#9CA3AF" }}>({product.reviews})</span>
        </div>
        <div style={{ display: "flex", alignItems: "center", gap: 6, marginBottom: compact ? 8 : 10 }}>
          <span style={{ fontSize: compact ? 14 : 16, fontWeight: 800, color: "#FF6B35" }}>{formatPrice(product.price)}</span>
          {product.originalPrice && <span style={{ fontSize: 11, color: "#9CA3AF", textDecoration: "line-through" }}>{formatPrice(product.originalPrice)}</span>}
        </div>
        <button onClick={e => { e.stopPropagation(); onAddCart(product); }} style={{ width: "100%", background: "linear-gradient(135deg, #FF6B35, #FF4500)", color: "#fff", border: "none", borderRadius: 10, padding: compact ? "7px" : "9px", fontWeight: 700, fontSize: compact ? 11 : 12, cursor: "pointer", fontFamily: "inherit" }}>
          🛒 Ба сабад
        </button>
      </div>
    </div>
  );
};

// ============================================================
// SHOP CARD
// ============================================================
const ShopCard = ({ shop, onOpen }) => (
  <div onClick={() => onOpen(shop)} style={{ background: "#fff", borderRadius: 16, padding: 16, boxShadow: "0 2px 12px rgba(0,0,0,0.07)", cursor: "pointer", transition: "transform 0.2s" }}
    onMouseEnter={e => e.currentTarget.style.transform = "translateY(-2px)"}
    onMouseLeave={e => e.currentTarget.style.transform = ""}>
    <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 10 }}>
      <div style={{ width: 48, height: 48, borderRadius: 12, background: "linear-gradient(135deg, #FFF3E0, #FFE0CC)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 24 }}>{shop.logo}</div>
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
          <span style={{ fontWeight: 700, fontSize: 14, color: "#1F2937", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{shop.name}</span>
          {shop.verified && <span title="Тасдиқшуда">✅</span>}
        </div>
        <div style={{ fontSize: 11, color: "#6B7280" }}>{shop.city}</div>
      </div>
      <div style={{ textAlign: "right" }}>
        <div style={{ fontSize: 12, fontWeight: 700, color: "#F59E0B" }}>⭐ {shop.rating}</div>
        <div style={{ fontSize: 10, color: "#9CA3AF" }}>{shop.products} маҳсулот</div>
      </div>
    </div>
    <div style={{ fontSize: 12, color: "#6B7280", marginBottom: 10, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{shop.description}</div>
    <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
      <Tag color={shop.plan === "premium" ? "#FFFBEB" : shop.plan === "standard" ? "#EFF6FF" : "#F9FAFB"} textColor={shop.plan === "premium" ? "#D97706" : shop.plan === "standard" ? "#3B82F6" : "#6B7280"}>
        {shop.plan === "premium" ? "👑 Премиум" : shop.plan === "standard" ? "⭐ Стандартӣ" : "Базавӣ"}
      </Tag>
      <span style={{ fontSize: 11, color: "#9CA3AF" }}>👥 {shop.followers.toLocaleString()}</span>
    </div>
  </div>
);

// ============================================================
// ORDER TRACKER
// ============================================================
const OrderTracker = ({ order }) => {
  const steps = ["ordered", "processing", "shipped", "delivered"];
  const stepLabels = ["Фармоиш", "Коркард", "Равона", "Расид"];
  const stepIcons = ["📋", "⚙️", "🚚", "✅"];
  const current = steps.indexOf(order.status);
  return (
    <div style={{ background: "#fff", borderRadius: 16, padding: 16, boxShadow: "0 2px 12px rgba(0,0,0,0.07)", marginBottom: 12 }}>
      <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 14 }}>
        <span style={{ fontSize: 28 }}>{order.icon}</span>
        <div>
          <div style={{ fontWeight: 700, fontSize: 14, color: "#1F2937" }}>{order.product}</div>
          <div style={{ fontSize: 12, color: "#6B7280" }}>{order.id} • {order.date}</div>
        </div>
        <div style={{ marginLeft: "auto", fontWeight: 800, color: "#FF6B35", fontSize: 14 }}>{formatPrice(order.total)}</div>
      </div>
      <div style={{ display: "flex", alignItems: "center", gap: 0 }}>
        {steps.map((step, i) => (
          <div key={step} style={{ flex: 1, display: "flex", flexDirection: "column", alignItems: "center", position: "relative" }}>
            {i < steps.length - 1 && <div style={{ position: "absolute", top: 16, left: "50%", width: "100%", height: 3, background: i < current ? "#10B981" : "#E5E7EB", zIndex: 0 }} />}
            <div style={{ width: 32, height: 32, borderRadius: "50%", background: i <= current ? "#10B981" : "#E5E7EB", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 14, zIndex: 1, position: "relative", boxShadow: i === current ? "0 0 0 3px rgba(16,185,129,0.2)" : "none" }}>
              {stepIcons[i]}
            </div>
            <div style={{ fontSize: 10, color: i <= current ? "#10B981" : "#9CA3AF", fontWeight: i === current ? 700 : 400, marginTop: 4, textAlign: "center" }}>{stepLabels[i]}</div>
          </div>
        ))}
      </div>
    </div>
  );
};

// ============================================================
// MODAL OVERLAY
// ============================================================
const Modal = ({ children, onClose }) => (
  <div style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,0.5)", display: "flex", alignItems: "flex-end", justifyContent: "center", zIndex: 1000, backdropFilter: "blur(4px)" }} onClick={onClose}>
    <div style={{ background: "#fff", borderRadius: "24px 24px 0 0", width: "100%", maxWidth: 480, maxHeight: "90vh", overflow: "auto", padding: 24, boxShadow: "0 -10px 40px rgba(0,0,0,0.15)" }} onClick={e => e.stopPropagation()}>
      {children}
    </div>
  </div>
);

// ============================================================
// PRODUCT DETAIL MODAL
// ============================================================
const ProductDetail = ({ product, onClose, onAddCart }) => {
  const shop = getShop(product.shopId);
  const [qty, setQty] = useState(1);
  const [tab, setTab] = useState("info");
  const [chatMsg, setChatMsg] = useState("");
  const [messages, setMessages] = useState([{ from: "seller", text: "Салом! Чӣ тавр метавонам ёрӣ расонам?" }]);
  const disc = product.originalPrice ? Math.round((1 - product.price / product.originalPrice) * 100) : 0;

  const sendMsg = () => {
    if (!chatMsg.trim()) return;
    setMessages(prev => [...prev, { from: "buyer", text: chatMsg }, { from: "seller", text: "Ташаккур барои саволатон! Мо тез ҷавоб хоҳем дод. 😊" }]);
    setChatMsg("");
  };

  return (
    <Modal onClose={onClose}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 16 }}>
        <div style={{ fontWeight: 800, fontSize: 18, color: "#1F2937" }}>Маълумоти маҳсулот</div>
        <button onClick={onClose} style={{ background: "#F3F4F6", border: "none", borderRadius: "50%", width: 36, height: 36, cursor: "pointer", fontSize: 18 }}>✕</button>
      </div>

      <div style={{ height: 200, background: "linear-gradient(135deg, #FFF8F0, #FFEFDF)", borderRadius: 16, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 90, marginBottom: 16, position: "relative" }}>
        {product.image}
        {product.video && (
          <div style={{ position: "absolute", bottom: 12, right: 12, background: "rgba(0,0,0,0.7)", borderRadius: 20, padding: "4px 12px", color: "#fff", fontSize: 12, fontWeight: 700, cursor: "pointer" }}>
            ▶ Видео тамошо кун
          </div>
        )}
        {disc > 0 && <div style={{ position: "absolute", top: 12, left: 12, background: "#EF4444", color: "#fff", borderRadius: 20, padding: "4px 10px", fontSize: 12, fontWeight: 700 }}>-{disc}%</div>}
      </div>

      <div style={{ fontWeight: 800, fontSize: 20, color: "#1F2937", marginBottom: 6 }}>{product.name}</div>
      <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 12 }}>
        <Stars rating={product.rating} size={14} />
        <span style={{ fontSize: 12, color: "#6B7280" }}>{product.reviews} шарҳ</span>
        <Tag>📦 {product.weight}кг</Tag>
        {product.badge && <Badge text={product.badge} />}
      </div>

      <div style={{ display: "flex", alignItems: "baseline", gap: 10, marginBottom: 16 }}>
        <span style={{ fontSize: 26, fontWeight: 900, color: "#FF6B35" }}>{formatPrice(product.price * qty)}</span>
        {product.originalPrice && <span style={{ fontSize: 16, color: "#9CA3AF", textDecoration: "line-through" }}>{formatPrice(product.originalPrice)}</span>}
      </div>

      {/* Tabs */}
      <div style={{ display: "flex", gap: 4, marginBottom: 16, background: "#F3F4F6", borderRadius: 12, padding: 4 }}>
        {["info", "shop", "chat", "reviews"].map(t => (
          <button key={t} onClick={() => setTab(t)} style={{ flex: 1, border: "none", borderRadius: 9, padding: "8px 4px", fontWeight: 700, fontSize: 12, cursor: "pointer", background: tab === t ? "#fff" : "transparent", color: tab === t ? "#FF6B35" : "#6B7280", fontFamily: "inherit", boxShadow: tab === t ? "0 2px 8px rgba(0,0,0,0.08)" : "none" }}>
            {t === "info" ? "ℹ️ Маълумот" : t === "shop" ? "🏪 Дӯкон" : t === "chat" ? "💬 Чат" : "⭐ Шарҳ"}
          </button>
        ))}
      </div>

      {tab === "info" && (
        <div>
          <p style={{ fontSize: 13, color: "#4B5563", lineHeight: 1.6, marginBottom: 12 }}>{product.description}</p>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 8 }}>
            <div style={{ background: "#F9FAFB", borderRadius: 10, padding: 10 }}><div style={{ fontSize: 11, color: "#9CA3AF" }}>Вазн</div><div style={{ fontWeight: 700 }}>{product.weight}кг</div></div>
            <div style={{ background: "#F9FAFB", borderRadius: 10, padding: 10 }}><div style={{ fontSize: 11, color: "#9CA3AF" }}>Захира</div><div style={{ fontWeight: 700 }}>{product.stock} дона</div></div>
          </div>
        </div>
      )}

      {tab === "shop" && shop && (
        <div style={{ background: "#F9FAFB", borderRadius: 12, padding: 14 }}>
          <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 10 }}>
            <div style={{ fontSize: 36 }}>{shop.logo}</div>
            <div>
              <div style={{ fontWeight: 700, fontSize: 15 }}>{shop.name}</div>
              <div style={{ fontSize: 12, color: "#6B7280" }}>{shop.city} • ✅ Тасдиқшуда</div>
            </div>
          </div>
          <div style={{ fontSize: 12, color: "#4B5563", marginBottom: 8 }}>{shop.description}</div>
          <div style={{ display: "flex", gap: 8 }}>
            <Tag>⭐ {shop.rating}</Tag>
            <Tag color="#F0FDF4" textColor="#10B981">👥 {shop.followers.toLocaleString()} донабинандагон</Tag>
          </div>
        </div>
      )}

      {tab === "chat" && (
        <div>
          <div style={{ height: 160, overflowY: "auto", marginBottom: 10, display: "flex", flexDirection: "column", gap: 8 }}>
            {messages.map((m, i) => (
              <div key={i} style={{ display: "flex", justifyContent: m.from === "buyer" ? "flex-end" : "flex-start" }}>
                <div style={{ background: m.from === "buyer" ? "#FF6B35" : "#F3F4F6", color: m.from === "buyer" ? "#fff" : "#1F2937", borderRadius: 12, padding: "8px 12px", fontSize: 13, maxWidth: "75%" }}>{m.text}</div>
              </div>
            ))}
          </div>
          <div style={{ display: "flex", gap: 8 }}>
            <input value={chatMsg} onChange={e => setChatMsg(e.target.value)} onKeyDown={e => e.key === "Enter" && sendMsg()} placeholder="Паём нависед..." style={{ flex: 1, border: "1.5px solid #E5E7EB", borderRadius: 10, padding: "9px 12px", fontSize: 13, outline: "none", fontFamily: "inherit" }} />
            <Btn onClick={sendMsg}>➤</Btn>
          </div>
        </div>
      )}

      {tab === "reviews" && (
        <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
          {[{ name: "Аҳмад Р.", text: "Маҳсулоти олӣ! Тавсия медиҳам.", stars: 5, date: "12.11.2024" }, { name: "Зарина М.", text: "Ба маъқул омад, вале бастабандӣ беҳтар шавад.", stars: 4, date: "08.11.2024" }].map((r, i) => (
            <div key={i} style={{ background: "#F9FAFB", borderRadius: 12, padding: 12 }}>
              <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 4 }}>
                <span style={{ fontWeight: 700, fontSize: 13 }}>{r.name}</span>
                <span style={{ fontSize: 11, color: "#9CA3AF" }}>{r.date}</span>
              </div>
              <Stars rating={r.stars} size={12} />
              <p style={{ fontSize: 12, color: "#4B5563", marginTop: 4 }}>{r.text}</p>
            </div>
          ))}
        </div>
      )}

      <div style={{ marginTop: 16, display: "flex", alignItems: "center", gap: 10 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 8, background: "#F3F4F6", borderRadius: 10, padding: "6px 12px" }}>
          <button onClick={() => setQty(q => Math.max(1, q - 1))} style={{ background: "none", border: "none", fontWeight: 700, fontSize: 18, cursor: "pointer", color: "#FF6B35" }}>−</button>
          <span style={{ fontWeight: 700, fontSize: 16, minWidth: 20, textAlign: "center" }}>{qty}</span>
          <button onClick={() => setQty(q => q + 1)} style={{ background: "none", border: "none", fontWeight: 700, fontSize: 18, cursor: "pointer", color: "#FF6B35" }}>+</button>
        </div>
        <Btn onClick={() => { onAddCart({ ...product, qty }); onClose(); }} style={{ flex: 1, padding: "12px" }}>
          🛒 Ба сабад ({formatPrice(product.price * qty)})
        </Btn>
      </div>
    </Modal>
  );
};

// ============================================================
// VIDEO BAZAAR
// ============================================================
const VideoBazaar = ({ onAddCart, onOpenProduct }) => {
  const videoProducts = PRODUCTS.filter(p => p.video);
  const [current, setCurrent] = useState(0);
  const p = videoProducts[current];

  return (
    <div style={{ background: "#000", borderRadius: 20, overflow: "hidden", position: "relative", height: 480 }}>
      <div style={{ height: "100%", background: `linear-gradient(160deg, #1a1a2e, #16213e, #0f3460)`, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 120 }}>
        {p.image}
      </div>
      {/* Overlay */}
      <div style={{ position: "absolute", inset: 0, background: "linear-gradient(to top, rgba(0,0,0,0.9) 0%, transparent 50%)" }} />

      {/* Controls */}
      <div style={{ position: "absolute", top: 16, left: 16, right: 16, display: "flex", justifyContent: "space-between", alignItems: "center" }}>
        <div style={{ background: "rgba(0,0,0,0.6)", borderRadius: 20, padding: "4px 12px", color: "#fff", fontSize: 12, fontWeight: 700 }}>📹 Видео Бозор</div>
        <div style={{ display: "flex", gap: 6 }}>
          {videoProducts.map((_, i) => <div key={i} style={{ width: 6, height: 6, borderRadius: "50%", background: i === current ? "#FF6B35" : "rgba(255,255,255,0.4)" }} />)}
        </div>
      </div>

      {/* Nav buttons */}
      <button onClick={() => setCurrent(c => (c - 1 + videoProducts.length) % videoProducts.length)} style={{ position: "absolute", left: 12, top: "50%", transform: "translateY(-50%)", background: "rgba(255,255,255,0.2)", border: "none", borderRadius: "50%", width: 40, height: 40, color: "#fff", fontSize: 18, cursor: "pointer" }}>‹</button>
      <button onClick={() => setCurrent(c => (c + 1) % videoProducts.length)} style={{ position: "absolute", right: 12, top: "50%", transform: "translateY(-50%)", background: "rgba(255,255,255,0.2)", border: "none", borderRadius: "50%", width: 40, height: 40, color: "#fff", fontSize: 18, cursor: "pointer" }}>›</button>

      {/* Product info */}
      <div style={{ position: "absolute", bottom: 0, left: 0, right: 0, padding: "20px 20px 24px" }}>
        <div style={{ display: "flex", alignItems: "flex-end", justifyContent: "space-between" }}>
          <div style={{ flex: 1 }}>
            <div style={{ color: "#fff", fontWeight: 800, fontSize: 18, marginBottom: 4 }}>{p.name}</div>
            <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 8 }}>
              <Stars rating={p.rating} size={13} />
              <span style={{ color: "rgba(255,255,255,0.7)", fontSize: 12 }}>{p.reviews} шарҳ</span>
            </div>
            <div style={{ color: "#FF6B35", fontWeight: 900, fontSize: 22 }}>{formatPrice(p.price)}</div>
          </div>
          <div style={{ display: "flex", flexDirection: "column", gap: 8, marginLeft: 16 }}>
            <button onClick={() => onOpenProduct(p)} style={{ background: "rgba(255,255,255,0.2)", border: "1px solid rgba(255,255,255,0.4)", borderRadius: 12, width: 48, height: 48, color: "#fff", fontSize: 20, cursor: "pointer" }}>👁️</button>
            <button onClick={() => onAddCart(p)} style={{ background: "#FF6B35", border: "none", borderRadius: 12, width: 48, height: 48, color: "#fff", fontSize: 20, cursor: "pointer" }}>🛒</button>
          </div>
        </div>
      </div>
    </div>
  );
};

// ============================================================
// MAP FEATURE (Simulated)
// ============================================================
const MapView = () => {
  const [selected, setSelected] = useState(null);
  const pins = [
    { id: 1, shop: SHOPS[0], x: 48, y: 38 }, { id: 2, shop: SHOPS[1], x: 55, y: 52 },
    { id: 3, shop: SHOPS[3], x: 35, y: 60 }, { id: 4, shop: SHOPS[2], x: 62, y: 40 },
    { id: 5, shop: SHOPS[4], x: 25, y: 45 },
  ];
  return (
    <div style={{ borderRadius: 16, overflow: "hidden", position: "relative", height: 280 }}>
      {/* Fake map background */}
      <div style={{ width: "100%", height: "100%", background: "linear-gradient(135deg, #E8F4FD 0%, #DDEFFA 25%, #E8F4FD 50%, #D5EAF7 75%, #E0F2FE 100%)", position: "relative" }}>
        {/* Grid lines for map feel */}
        {[...Array(8)].map((_, i) => <div key={i} style={{ position: "absolute", left: `${i * 14}%`, top: 0, bottom: 0, borderLeft: "1px solid rgba(100,150,200,0.15)" }} />)}
        {[...Array(6)].map((_, i) => <div key={i} style={{ position: "absolute", top: `${i * 20}%`, left: 0, right: 0, borderTop: "1px solid rgba(100,150,200,0.15)" }} />)}
        {/* Streets */}
        <div style={{ position: "absolute", top: "45%", left: 0, right: 0, height: 6, background: "rgba(180,200,220,0.5)", borderRadius: 3 }} />
        <div style={{ position: "absolute", top: 0, bottom: 0, left: "50%", width: 6, background: "rgba(180,200,220,0.5)", borderRadius: 3 }} />
        <div style={{ position: "absolute", top: "30%", left: "20%", right: "15%", height: 4, background: "rgba(200,220,240,0.4)", borderRadius: 2, transform: "rotate(-5deg)" }} />

        {/* Map label */}
        <div style={{ position: "absolute", top: 12, left: 12, background: "rgba(255,255,255,0.9)", borderRadius: 10, padding: "4px 10px", fontSize: 11, fontWeight: 700, color: "#374151" }}>📍 Душанбе</div>

        {/* Pins */}
        {pins.map(pin => (
          <div key={pin.id} onClick={() => setSelected(selected?.id === pin.id ? null : pin)} style={{ position: "absolute", left: `${pin.x}%`, top: `${pin.y}%`, transform: "translate(-50%, -100%)", cursor: "pointer", zIndex: 10 }}>
            <div style={{ background: pin.shop.plan === "premium" ? "#FF6B35" : "#3B82F6", borderRadius: "50% 50% 50% 0", width: 32, height: 32, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 16, boxShadow: "0 3px 10px rgba(0,0,0,0.2)", transform: "rotate(-45deg)" }}>
              <span style={{ transform: "rotate(45deg)" }}>{pin.shop.logo}</span>
            </div>
          </div>
        ))}

        {/* Selected popup */}
        {selected && (
          <div style={{ position: "absolute", left: `${Math.min(selected.x, 70)}%`, top: `${Math.max(selected.y - 45, 5)}%`, background: "#fff", borderRadius: 12, padding: "10px 14px", boxShadow: "0 4px 20px rgba(0,0,0,0.15)", minWidth: 160, zIndex: 20 }}>
            <div style={{ fontWeight: 700, fontSize: 13 }}>{selected.shop.name}</div>
            <div style={{ fontSize: 11, color: "#6B7280", marginBottom: 4 }}>{selected.shop.city}</div>
            <div style={{ display: "flex", gap: 6 }}>
              <Tag color="#FFF3E0" textColor="#FF6B35">⭐ {selected.shop.rating}</Tag>
              <Tag>{selected.shop.products} маҳсулот</Tag>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

// ============================================================
// PAGES
// ============================================================

// HOME PAGE
const HomePage = ({ onOpenProduct, onAddCart, onOpenShop, setPage }) => {
  const [search, setSearch] = useState("");
  const [notifVisible, setNotifVisible] = useState(false);
  const trending = PRODUCTS.filter(p => p.badge).slice(0, 6);
  const featured = SHOPS.filter(s => s.featured);
  const discounted = PRODUCTS.filter(p => p.originalPrice).slice(0, 4);

  return (
    <div style={{ paddingBottom: 80 }}>
      {/* Header */}
      <div style={{ background: "linear-gradient(135deg, #FF6B35 0%, #FF4500 60%, #FF6B35 100%)", padding: "20px 20px 30px", position: "relative", overflow: "hidden" }}>
        <div style={{ position: "absolute", top: -30, right: -30, width: 120, height: 120, borderRadius: "50%", background: "rgba(255,255,255,0.1)" }} />
        <div style={{ position: "absolute", bottom: -20, left: -20, width: 80, height: 80, borderRadius: "50%", background: "rgba(255,255,255,0.08)" }} />
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 16 }}>
          <div>
            <div style={{ fontSize: 11, color: "rgba(255,255,255,0.8)", marginBottom: 2 }}>🇹🇯 Тоҷикистон</div>
            <div style={{ fontSize: 22, fontWeight: 900, color: "#fff", letterSpacing: -0.5 }}>SavdoHub</div>
          </div>
          <div style={{ display: "flex", gap: 10 }}>
            <button onClick={() => setNotifVisible(!notifVisible)} style={{ background: "rgba(255,255,255,0.2)", border: "none", borderRadius: "50%", width: 40, height: 40, color: "#fff", fontSize: 18, cursor: "pointer", position: "relative" }}>
              🔔
              <div style={{ position: "absolute", top: 6, right: 6, width: 10, height: 10, borderRadius: "50%", background: "#FBBF24", border: "2px solid #FF6B35" }} />
            </button>
            <button onClick={() => setPage("profile")} style={{ background: "rgba(255,255,255,0.2)", border: "none", borderRadius: "50%", width: 40, height: 40, color: "#fff", fontSize: 18, cursor: "pointer" }}>👤</button>
          </div>
        </div>
        <div style={{ display: "flex", gap: 10, alignItems: "center", background: "#fff", borderRadius: 14, padding: "10px 14px", boxShadow: "0 4px 20px rgba(0,0,0,0.15)" }}>
          <span style={{ fontSize: 18, color: "#9CA3AF" }}>🔍</span>
          <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Маҳсулот ҷустуҷӯ кун..." style={{ flex: 1, border: "none", outline: "none", fontSize: 14, color: "#1F2937", fontFamily: "inherit" }} />
          {search && <button onClick={() => setSearch("")} style={{ border: "none", background: "none", cursor: "pointer", color: "#9CA3AF", fontSize: 16 }}>✕</button>}
        </div>
        {/* Notif dropdown */}
        {notifVisible && (
          <div style={{ position: "absolute", top: 80, right: 20, background: "#fff", borderRadius: 16, boxShadow: "0 8px 32px rgba(0,0,0,0.2)", width: 280, zIndex: 100, overflow: "hidden" }}>
            <div style={{ padding: "14px 16px", borderBottom: "1px solid #F3F4F6", fontWeight: 700, fontSize: 14 }}>🔔 Огоҳиномаҳо</div>
            {[{ icon: "🛒", text: "Фармоиши шумо равона шуд!", time: "5 дақ пеш" }, { icon: "⭐", text: "TechHub маҳсулоти нав илова кард", time: "1 соат пеш" }, { icon: "🎁", text: "Тахфиф 20% барои шумо!", time: "2 соат пеш" }].map((n, i) => (
              <div key={i} style={{ padding: "12px 16px", display: "flex", gap: 10, borderBottom: "1px solid #F9FAFB" }}>
                <span style={{ fontSize: 20 }}>{n.icon}</span>
                <div><div style={{ fontSize: 13, color: "#1F2937" }}>{n.text}</div><div style={{ fontSize: 11, color: "#9CA3AF" }}>{n.time}</div></div>
              </div>
            ))}
          </div>
        )}
      </div>

      <div style={{ padding: "0 16px" }}>
        {/* Search results */}
        {search && (
          <div style={{ marginTop: 16 }}>
            <div style={{ fontWeight: 700, fontSize: 16, marginBottom: 12, color: "#1F2937" }}>Натиҷаҳои ҷустуҷӯ: "{search}"</div>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
              {PRODUCTS.filter(p => p.name.toLowerCase().includes(search.toLowerCase())).map(p => <ProductCard key={p.id} product={p} onOpen={onOpenProduct} onAddCart={onAddCart} compact />)}
            </div>
            {PRODUCTS.filter(p => p.name.toLowerCase().includes(search.toLowerCase())).length === 0 && (
              <div style={{ textAlign: "center", padding: 40, color: "#9CA3AF" }}>😕 Маҳсулот ёфт нашуд</div>
            )}
          </div>
        )}

        {!search && <>
          {/* Categories */}
          <div style={{ marginTop: 20, marginBottom: 20 }}>
            <div style={{ fontWeight: 800, fontSize: 17, marginBottom: 14, color: "#1F2937" }}>Категорияҳо</div>
            <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 10 }}>
              {CATEGORIES.map(cat => (
                <div key={cat.id} onClick={() => setPage("catalog")} style={{ background: "#fff", borderRadius: 14, padding: "12px 8px", textAlign: "center", cursor: "pointer", boxShadow: "0 2px 8px rgba(0,0,0,0.06)", transition: "transform 0.15s" }}
                  onMouseEnter={e => e.currentTarget.style.transform = "scale(1.05)"}
                  onMouseLeave={e => e.currentTarget.style.transform = ""}>
                  <div style={{ fontSize: 26, marginBottom: 4 }}>{cat.icon}</div>
                  <div style={{ fontSize: 11, fontWeight: 600, color: "#374151" }}>{cat.name}</div>
                </div>
              ))}
            </div>
          </div>

          {/* Promo Banner */}
          <div style={{ background: "linear-gradient(135deg, #1a1a2e, #16213e)", borderRadius: 18, padding: "20px", marginBottom: 20, position: "relative", overflow: "hidden" }}>
            <div style={{ position: "absolute", right: 20, top: "50%", transform: "translateY(-50%)", fontSize: 72, opacity: 0.3 }}>🛍️</div>
            <div style={{ fontSize: 11, color: "#FF6B35", fontWeight: 700, marginBottom: 6 }}>🎁 МАХСУС ПЕШНИҲОД</div>
            <div style={{ fontSize: 20, fontWeight: 900, color: "#fff", marginBottom: 6 }}>Тахфиф то 50%!</div>
            <div style={{ fontSize: 13, color: "rgba(255,255,255,0.7)", marginBottom: 14 }}>Дар маҳсулоти интихобшуда</div>
            <Btn onClick={() => setPage("catalog")} style={{ padding: "10px 20px", fontSize: 13 }}>Хариди кун →</Btn>
          </div>

          {/* Video Bazaar */}
          <div style={{ marginBottom: 20 }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 14 }}>
              <div style={{ fontWeight: 800, fontSize: 17, color: "#1F2937" }}>📹 Видео Бозор</div>
              <span style={{ fontSize: 12, color: "#FF6B35", fontWeight: 600, cursor: "pointer" }}>Ҳама</span>
            </div>
            <VideoBazaar onAddCart={onAddCart} onOpenProduct={onOpenProduct} />
          </div>

          {/* Trending */}
          <div style={{ marginBottom: 20 }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 14 }}>
              <div style={{ fontWeight: 800, fontSize: 17, color: "#1F2937" }}>🔥 Маъмултаринҳо</div>
              <span onClick={() => setPage("catalog")} style={{ fontSize: 12, color: "#FF6B35", fontWeight: 600, cursor: "pointer" }}>Ҳама →</span>
            </div>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
              {trending.map(p => <ProductCard key={p.id} product={p} onOpen={onOpenProduct} onAddCart={onAddCart} compact />)}
            </div>
          </div>

          {/* Map */}
          <div style={{ marginBottom: 20 }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 14 }}>
              <div style={{ fontWeight: 800, fontSize: 17, color: "#1F2937" }}>🗺️ Дӯконҳои наздик</div>
              <span style={{ fontSize: 12, color: "#FF6B35", fontWeight: 600, cursor: "pointer" }}>Нақша →</span>
            </div>
            <MapView />
          </div>

          {/* Featured Shops */}
          <div style={{ marginBottom: 20 }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 14 }}>
              <div style={{ fontWeight: 800, fontSize: 17, color: "#1F2937" }}>🏆 Дӯконҳои Беҳтарин</div>
              <span onClick={() => setPage("shops")} style={{ fontSize: 12, color: "#FF6B35", fontWeight: 600, cursor: "pointer" }}>Ҳама →</span>
            </div>
            <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
              {featured.map(s => <ShopCard key={s.id} shop={s} onOpen={onOpenShop} />)}
            </div>
          </div>

          {/* Discounts */}
          <div style={{ marginBottom: 20 }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 14 }}>
              <div style={{ fontWeight: 800, fontSize: 17, color: "#1F2937" }}>🏷️ Тахфифҳо</div>
              <span style={{ fontSize: 12, color: "#FF6B35", fontWeight: 600, cursor: "pointer" }}>Ҳама →</span>
            </div>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
              {discounted.map(p => <ProductCard key={p.id} product={p} onOpen={onOpenProduct} onAddCart={onAddCart} compact />)}
            </div>
          </div>

          {/* Referral Banner */}
          <div style={{ background: "linear-gradient(135deg, #10B981, #059669)", borderRadius: 18, padding: 20, marginBottom: 20 }}>
            <div style={{ fontSize: 22, fontWeight: 900, color: "#fff", marginBottom: 6 }}>🎁 Дӯсти худро даъват кун!</div>
            <div style={{ fontSize: 13, color: "rgba(255,255,255,0.9)", marginBottom: 14 }}>Шумо ва дӯстатон ҳар кадом 5 сомонӣ бонус мегиред</div>
            <Btn variant="secondary" style={{ borderRadius: 10 }}>🔗 Истинодро нусха кун</Btn>
          </div>
        </>}
      </div>
    </div>
  );
};

// CATALOG PAGE
const CatalogPage = ({ onOpenProduct, onAddCart }) => {
  const [activeCategory, setActiveCategory] = useState("all");
  const [sort, setSort] = useState("popular");
  const [filter, setFilter] = useState(false);
  const [priceRange, setPriceRange] = useState([0, 10000]);

  const filtered = PRODUCTS
    .filter(p => activeCategory === "all" || p.category === activeCategory)
    .filter(p => p.price >= priceRange[0] && p.price <= priceRange[1])
    .sort((a, b) => sort === "price_asc" ? a.price - b.price : sort === "price_desc" ? b.price - a.price : b.rating - a.rating);

  return (
    <div style={{ paddingBottom: 80 }}>
      <div style={{ background: "#fff", padding: "16px 16px 0", boxShadow: "0 2px 10px rgba(0,0,0,0.05)", position: "sticky", top: 0, zIndex: 50 }}>
        <div style={{ fontWeight: 800, fontSize: 18, color: "#1F2937", marginBottom: 12 }}>🛍️ Маҳсулотҳо</div>
        <div style={{ display: "flex", gap: 8, overflowX: "auto", paddingBottom: 12 }}>
          <button onClick={() => setActiveCategory("all")} style={{ flexShrink: 0, border: "none", borderRadius: 20, padding: "7px 14px", fontWeight: 700, fontSize: 12, cursor: "pointer", background: activeCategory === "all" ? "#FF6B35" : "#F3F4F6", color: activeCategory === "all" ? "#fff" : "#374151", fontFamily: "inherit" }}>Ҳама</button>
          {CATEGORIES.map(cat => (
            <button key={cat.id} onClick={() => setActiveCategory(cat.id)} style={{ flexShrink: 0, border: "none", borderRadius: 20, padding: "7px 14px", fontWeight: 700, fontSize: 12, cursor: "pointer", background: activeCategory === cat.id ? "#FF6B35" : "#F3F4F6", color: activeCategory === cat.id ? "#fff" : "#374151", fontFamily: "inherit" }}>
              {cat.icon} {cat.name}
            </button>
          ))}
        </div>
        <div style={{ display: "flex", gap: 8, paddingBottom: 12 }}>
          <select value={sort} onChange={e => setSort(e.target.value)} style={{ flex: 1, border: "1.5px solid #E5E7EB", borderRadius: 10, padding: "8px 12px", fontSize: 12, fontWeight: 600, fontFamily: "inherit", outline: "none" }}>
            <option value="popular">⭐ Маъмултарин</option>
            <option value="price_asc">💰 Нарх: паст → боло</option>
            <option value="price_desc">💰 Нарх: боло → паст</option>
          </select>
          <button onClick={() => setFilter(!filter)} style={{ background: filter ? "#FF6B35" : "#F3F4F6", border: "none", borderRadius: 10, padding: "8px 14px", fontWeight: 700, fontSize: 12, cursor: "pointer", color: filter ? "#fff" : "#374151", fontFamily: "inherit" }}>⚙️ Филтр</button>
        </div>
        {filter && (
          <div style={{ paddingBottom: 12 }}>
            <div style={{ fontSize: 12, fontWeight: 600, color: "#6B7280", marginBottom: 8 }}>Диапазони нарх: {formatPrice(priceRange[0])} — {formatPrice(priceRange[1])}</div>
            <div style={{ display: "flex", gap: 8 }}>
              <input type="number" value={priceRange[0]} onChange={e => setPriceRange([+e.target.value, priceRange[1]])} placeholder="Аз" style={{ flex: 1, border: "1.5px solid #E5E7EB", borderRadius: 10, padding: "8px 12px", fontSize: 12, fontFamily: "inherit", outline: "none" }} />
              <input type="number" value={priceRange[1]} onChange={e => setPriceRange([priceRange[0], +e.target.value])} placeholder="То" style={{ flex: 1, border: "1.5px solid #E5E7EB", borderRadius: 10, padding: "8px 12px", fontSize: 12, fontFamily: "inherit", outline: "none" }} />
            </div>
          </div>
        )}
      </div>
      <div style={{ padding: "16px" }}>
        <div style={{ fontSize: 12, color: "#9CA3AF", marginBottom: 12 }}>{filtered.length} маҳсулот ёфт шуд</div>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
          {filtered.map(p => <ProductCard key={p.id} product={p} onOpen={onOpenProduct} onAddCart={onAddCart} compact />)}
        </div>
      </div>
    </div>
  );
};

// SHOPS PAGE
const ShopsPage = ({ onOpenShop }) => {
  const [search, setSearch] = useState("");
  const [planFilter, setPlanFilter] = useState("all");
  const filtered = SHOPS.filter(s => (planFilter === "all" || s.plan === planFilter) && (s.name.toLowerCase().includes(search.toLowerCase())));

  return (
    <div style={{ paddingBottom: 80 }}>
      <div style={{ background: "#fff", padding: "16px 16px 0", boxShadow: "0 2px 10px rgba(0,0,0,0.05)", position: "sticky", top: 0, zIndex: 50 }}>
        <div style={{ fontWeight: 800, fontSize: 18, color: "#1F2937", marginBottom: 12 }}>🏪 Дӯконҳо</div>
        <div style={{ display: "flex", gap: 8, marginBottom: 10, background: "#F3F4F6", borderRadius: 12, padding: "8px 12px" }}>
          <span style={{ fontSize: 16, color: "#9CA3AF" }}>🔍</span>
          <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Дӯкон ҷустуҷӯ..." style={{ flex: 1, border: "none", background: "none", outline: "none", fontSize: 13, fontFamily: "inherit" }} />
        </div>
        <div style={{ display: "flex", gap: 8, paddingBottom: 12 }}>
          {["all", "premium", "standard", "basic"].map(p => (
            <button key={p} onClick={() => setPlanFilter(p)} style={{ flex: 1, border: "none", borderRadius: 20, padding: "7px 4px", fontWeight: 700, fontSize: 11, cursor: "pointer", background: planFilter === p ? "#FF6B35" : "#F3F4F6", color: planFilter === p ? "#fff" : "#374151", fontFamily: "inherit" }}>
              {p === "all" ? "Ҳама" : p === "premium" ? "👑 VIP" : p === "standard" ? "⭐ Стандарт" : "Базавӣ"}
            </button>
          ))}
        </div>
      </div>
      <div style={{ padding: 16, display: "flex", flexDirection: "column", gap: 12 }}>
        {filtered.map(s => <ShopCard key={s.id} shop={s} onOpen={onOpenShop} />)}
      </div>
    </div>
  );
};

// CART PAGE
const CartPage = ({ cart, setCart, setPage }) => {
  const [checkout, setCheckout] = useState(false);
  const [payMethod, setPayMethod] = useState("cod");
  const [address, setAddress] = useState("");
  const [phone, setPhone] = useState("");
  const [ordered, setOrdered] = useState(false);

  const total = cart.reduce((s, i) => s + i.price * (i.qty || 1), 0);
  const totalWeight = cart.reduce((s, i) => s + i.weight * (i.qty || 1), 0);
  const deliveryPrice = totalWeight <= 1 ? 15 : totalWeight <= 3 ? 25 : totalWeight <= 5 ? 35 : 50;

  const removeItem = (id) => setCart(prev => prev.filter(i => i.id !== id));
  const updateQty = (id, delta) => setCart(prev => prev.map(i => i.id === id ? { ...i, qty: Math.max(1, (i.qty || 1) + delta) } : i));

  if (ordered) return (
    <div style={{ padding: 32, textAlign: "center", paddingBottom: 100 }}>
      <div style={{ fontSize: 80, marginBottom: 16 }}>🎉</div>
      <div style={{ fontWeight: 900, fontSize: 22, color: "#1F2937", marginBottom: 8 }}>Фармоиш қабул шуд!</div>
      <div style={{ fontSize: 14, color: "#6B7280", marginBottom: 24 }}>Шумо метавонед ҳолати фармоишро пайгирӣ кунед</div>
      <Btn onClick={() => { setOrdered(false); setCart([]); setPage("orders"); }}>📦 Фармоишҳоро бин</Btn>
    </div>
  );

  if (cart.length === 0) return (
    <div style={{ padding: 32, textAlign: "center", paddingBottom: 100 }}>
      <div style={{ fontSize: 80, marginBottom: 16 }}>🛒</div>
      <div style={{ fontWeight: 700, fontSize: 18, color: "#1F2937", marginBottom: 8 }}>Сабад холӣ аст</div>
      <div style={{ fontSize: 13, color: "#6B7280", marginBottom: 24 }}>Маҳсулотҳоро ба сабад илова кунед</div>
      <Btn onClick={() => setPage("catalog")}>🛍️ Харид кун</Btn>
    </div>
  );

  return (
    <div style={{ paddingBottom: 100 }}>
      <div style={{ background: "#fff", padding: "16px 16px 8px", boxShadow: "0 2px 10px rgba(0,0,0,0.05)" }}>
        <div style={{ fontWeight: 800, fontSize: 18, color: "#1F2937" }}>🛒 Сабад ({cart.length})</div>
      </div>
      <div style={{ padding: 16 }}>
        {!checkout ? (
          <>
            {cart.map(item => (
              <div key={item.id} style={{ background: "#fff", borderRadius: 16, padding: 14, marginBottom: 10, display: "flex", gap: 12, alignItems: "center", boxShadow: "0 2px 8px rgba(0,0,0,0.06)" }}>
                <div style={{ width: 60, height: 60, borderRadius: 12, background: "#FFF8F0", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 32, flexShrink: 0 }}>{item.image}</div>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ fontWeight: 700, fontSize: 13, color: "#1F2937", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{item.name}</div>
                  <div style={{ fontWeight: 800, color: "#FF6B35", fontSize: 15 }}>{formatPrice(item.price)}</div>
                  <div style={{ display: "flex", alignItems: "center", gap: 8, marginTop: 6 }}>
                    <button onClick={() => updateQty(item.id, -1)} style={{ width: 28, height: 28, borderRadius: 8, border: "1.5px solid #E5E7EB", background: "#fff", cursor: "pointer", fontWeight: 700, fontSize: 14 }}>−</button>
                    <span style={{ fontWeight: 700, fontSize: 14, minWidth: 20, textAlign: "center" }}>{item.qty || 1}</span>
                    <button onClick={() => updateQty(item.id, 1)} style={{ width: 28, height: 28, borderRadius: 8, border: "1.5px solid #FF6B35", background: "#FFF3F0", cursor: "pointer", fontWeight: 700, fontSize: 14, color: "#FF6B35" }}>+</button>
                  </div>
                </div>
                <button onClick={() => removeItem(item.id)} style={{ background: "#FEE2E2", border: "none", borderRadius: 10, width: 34, height: 34, cursor: "pointer", color: "#EF4444", fontSize: 16, flexShrink: 0 }}>🗑️</button>
              </div>
            ))}

            {/* Delivery cost */}
            <div style={{ background: "#F0FDF4", borderRadius: 14, padding: 14, marginBottom: 14 }}>
              <div style={{ fontWeight: 700, fontSize: 13, color: "#065F46", marginBottom: 8 }}>🚚 Нархи таслим</div>
              <div style={{ display: "flex", justifyContent: "space-between", fontSize: 12, color: "#6B7280" }}>
                <span>Умумии вазн: {totalWeight.toFixed(1)}кг</span>
                <span style={{ fontWeight: 700, color: "#10B981" }}>{formatPrice(deliveryPrice)}</span>
              </div>
            </div>

            <div style={{ background: "#fff", borderRadius: 16, padding: 16, boxShadow: "0 2px 8px rgba(0,0,0,0.06)", marginBottom: 16 }}>
              <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 8, fontSize: 13, color: "#6B7280" }}>
                <span>Маҳсулот ({cart.length})</span>
                <span>{formatPrice(total)}</span>
              </div>
              <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 12, fontSize: 13, color: "#6B7280" }}>
                <span>Таслим</span>
                <span>{formatPrice(deliveryPrice)}</span>
              </div>
              <div style={{ borderTop: "1.5px dashed #E5E7EB", paddingTop: 12, display: "flex", justifyContent: "space-between", fontWeight: 800, fontSize: 17 }}>
                <span>Ҷамъ</span>
                <span style={{ color: "#FF6B35" }}>{formatPrice(total + deliveryPrice)}</span>
              </div>
            </div>
            <Btn onClick={() => setCheckout(true)} style={{ width: "100%", padding: "14px" }}>Фармоиш додан →</Btn>
          </>
        ) : (
          <>
            <div style={{ background: "#fff", borderRadius: 16, padding: 16, marginBottom: 14, boxShadow: "0 2px 8px rgba(0,0,0,0.06)" }}>
              <div style={{ fontWeight: 700, fontSize: 15, marginBottom: 14 }}>📋 Маълумоти таслим</div>
              <input value={address} onChange={e => setAddress(e.target.value)} placeholder="Суроға (шаҳр, кӯча, хона)" style={{ width: "100%", border: "1.5px solid #E5E7EB", borderRadius: 10, padding: "10px 12px", fontSize: 13, marginBottom: 10, fontFamily: "inherit", outline: "none", boxSizing: "border-box" }} />
              <input value={phone} onChange={e => setPhone(e.target.value)} placeholder="Рақами телефон" style={{ width: "100%", border: "1.5px solid #E5E7EB", borderRadius: 10, padding: "10px 12px", fontSize: 13, fontFamily: "inherit", outline: "none", boxSizing: "border-box" }} />
            </div>
            <div style={{ background: "#fff", borderRadius: 16, padding: 16, marginBottom: 14, boxShadow: "0 2px 8px rgba(0,0,0,0.06)" }}>
              <div style={{ fontWeight: 700, fontSize: 15, marginBottom: 12 }}>💳 Усули пардохт</div>
              {[{ id: "cod", label: "💵 Пул дар таслим", desc: "Баъд аз гирифтани маҳсулот пардохт кунед" }, { id: "card", label: "💳 Корти бонкӣ", desc: "Visa, Mastercard, SOMONI card" }, { id: "wallet", label: "📱 Ҳамёни рақамӣ", desc: "ALIF Pay, Korti Milli" }].map(m => (
                <div key={m.id} onClick={() => setPayMethod(m.id)} style={{ display: "flex", gap: 12, padding: 12, borderRadius: 12, border: `1.5px solid ${payMethod === m.id ? "#FF6B35" : "#E5E7EB"}`, marginBottom: 8, cursor: "pointer", background: payMethod === m.id ? "#FFF8F5" : "#fff" }}>
                  <div style={{ width: 20, height: 20, borderRadius: "50%", border: `2px solid ${payMethod === m.id ? "#FF6B35" : "#D1D5DB"}`, display: "flex", alignItems: "center", justifyContent: "center", marginTop: 2, flexShrink: 0 }}>
                    {payMethod === m.id && <div style={{ width: 10, height: 10, borderRadius: "50%", background: "#FF6B35" }} />}
                  </div>
                  <div><div style={{ fontWeight: 700, fontSize: 13 }}>{m.label}</div><div style={{ fontSize: 11, color: "#6B7280" }}>{m.desc}</div></div>
                </div>
              ))}
            </div>
            <div style={{ background: "#FFFBEB", borderRadius: 12, padding: 12, marginBottom: 16, fontSize: 12, color: "#92400E" }}>
              🔒 Пул аввал дар платформа нигоҳ дошта мешавад ва баъд аз тасдиқи шумо ба фурӯшанда дода мешавад.
            </div>
            <div style={{ display: "flex", gap: 10 }}>
              <Btn variant="secondary" onClick={() => setCheckout(false)}>← Бозгашт</Btn>
              <Btn onClick={() => setOrdered(true)} disabled={!address || !phone} style={{ flex: 1, padding: "14px" }}>✅ Тасдиқ ({formatPrice(total + deliveryPrice)})</Btn>
            </div>
          </>
        )}
      </div>
    </div>
  );
};

// ORDERS PAGE
const OrdersPage = () => (
  <div style={{ paddingBottom: 80 }}>
    <div style={{ background: "#fff", padding: "16px", boxShadow: "0 2px 10px rgba(0,0,0,0.05)" }}>
      <div style={{ fontWeight: 800, fontSize: 18, color: "#1F2937" }}>📦 Фармоишҳои ман</div>
    </div>
    <div style={{ padding: 16 }}>
      {ORDERS.map(order => <OrderTracker key={order.id} order={order} />)}
    </div>
  </div>
);

// PROFILE PAGE
const ProfilePage = ({ setPage, isLoggedIn, setIsLoggedIn }) => {
  const [tab, setTab] = useState("profile");
  const [referralCopied, setReferralCopied] = useState(false);

  const copyReferral = () => { setReferralCopied(true); setTimeout(() => setReferralCopied(false), 2000); };

  if (!isLoggedIn) return (
    <div style={{ padding: 24, paddingBottom: 100 }}>
      <div style={{ textAlign: "center", marginBottom: 32 }}>
        <div style={{ fontSize: 80, marginBottom: 12 }}>👤</div>
        <div style={{ fontWeight: 800, fontSize: 22, marginBottom: 8, color: "#1F2937" }}>Хуш омадед ба SavdoHub</div>
        <div style={{ fontSize: 13, color: "#6B7280" }}>Барои хариди осон ворид шавед</div>
      </div>
      <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
        <Btn onClick={() => setIsLoggedIn(true)} style={{ width: "100%", padding: "14px" }}>🔑 Ворид шавед</Btn>
        <Btn variant="outline" style={{ width: "100%", padding: "14px" }}>📱 Бо телефон</Btn>
        <div style={{ textAlign: "center", fontSize: 13, color: "#9CA3AF", margin: "10px 0" }}>— ё —</div>
        <Btn variant="secondary" style={{ width: "100%", padding: "14px" }}>✉️ Бо имейл</Btn>
        <div style={{ textAlign: "center", fontSize: 13, color: "#6B7280", marginTop: 10 }}>
          Ҳисоб надоред? <span style={{ color: "#FF6B35", fontWeight: 700, cursor: "pointer" }}>Бақайдгирӣ</span>
        </div>
      </div>
    </div>
  );

  return (
    <div style={{ paddingBottom: 80 }}>
      {/* Header */}
      <div style={{ background: "linear-gradient(135deg, #FF6B35, #FF4500)", padding: "24px 20px 30px" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 14, marginBottom: 16 }}>
          <div style={{ width: 64, height: 64, borderRadius: "50%", background: "rgba(255,255,255,0.2)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 30, border: "3px solid rgba(255,255,255,0.4)" }}>👨</div>
          <div>
            <div style={{ fontWeight: 800, fontSize: 18, color: "#fff" }}>Аҳмад Муродов</div>
            <div style={{ fontSize: 12, color: "rgba(255,255,255,0.8)" }}>+992 93 123 45 67</div>
            <div style={{ marginTop: 4 }}><Tag color="rgba(255,255,255,0.2)" textColor="#fff">🛍️ Харидор</Tag></div>
          </div>
        </div>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 8 }}>
          {[{ label: "Фармоиш", value: 4, icon: "📦" }, { label: "Дар сабад", value: 3, icon: "🛒" }, { label: "Бонус", value: "15 сом.", icon: "🎁" }].map(s => (
            <div key={s.label} style={{ background: "rgba(255,255,255,0.2)", borderRadius: 12, padding: "10px 8px", textAlign: "center" }}>
              <div style={{ fontSize: 20, marginBottom: 2 }}>{s.icon}</div>
              <div style={{ fontWeight: 800, fontSize: 16, color: "#fff" }}>{s.value}</div>
              <div style={{ fontSize: 10, color: "rgba(255,255,255,0.8)" }}>{s.label}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Tabs */}
      <div style={{ display: "flex", gap: 4, padding: "12px 16px", background: "#fff", boxShadow: "0 2px 10px rgba(0,0,0,0.05)", overflowX: "auto" }}>
        {["profile", "seller", "delivery", "plans"].map(t => (
          <button key={t} onClick={() => setTab(t)} style={{ flexShrink: 0, border: "none", borderRadius: 20, padding: "8px 14px", fontWeight: 700, fontSize: 12, cursor: "pointer", background: tab === t ? "#FF6B35" : "#F3F4F6", color: tab === t ? "#fff" : "#374151", fontFamily: "inherit" }}>
            {t === "profile" ? "👤 Профил" : t === "seller" ? "🏪 Фурӯшанда" : t === "delivery" ? "🚚 Таслим" : "💼 Нақшаҳо"}
          </button>
        ))}
      </div>

      <div style={{ padding: 16 }}>
        {tab === "profile" && (
          <div>
            {[{ icon: "❤️", label: "Дӯстдоштаҳо", value: "12 маҳсулот" }, { icon: "📦", label: "Фармоишҳо", action: () => setPage("orders") }, { icon: "🔔", label: "Огоҳиномаҳо", value: "3 нав" }, { icon: "📍", label: "Суроғаҳо", value: "1 суроға" }, { icon: "💬", label: "Паёмҳо", value: "2 нав" }, { icon: "⚙️", label: "Танзимот" }].map((item, i) => (
              <div key={i} onClick={item.action} style={{ background: "#fff", borderRadius: 14, padding: "14px 16px", marginBottom: 8, display: "flex", justifyContent: "space-between", alignItems: "center", boxShadow: "0 2px 6px rgba(0,0,0,0.05)", cursor: item.action ? "pointer" : "default" }}>
                <div style={{ display: "flex", gap: 12, alignItems: "center" }}>
                  <span style={{ fontSize: 20 }}>{item.icon}</span>
                  <span style={{ fontWeight: 600, fontSize: 14, color: "#1F2937" }}>{item.label}</span>
                </div>
                <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
                  {item.value && <span style={{ fontSize: 12, color: "#9CA3AF" }}>{item.value}</span>}
                  <span style={{ color: "#D1D5DB", fontSize: 18 }}>›</span>
                </div>
              </div>
            ))}

            <div style={{ background: "linear-gradient(135deg, #10B981, #059669)", borderRadius: 16, padding: 16, marginTop: 8 }}>
              <div style={{ fontWeight: 800, fontSize: 15, color: "#fff", marginBottom: 4 }}>🎁 Дӯсти даъват кун</div>
              <div style={{ fontSize: 12, color: "rgba(255,255,255,0.9)", marginBottom: 12 }}>Ҳар ду +5 сомонӣ бонус мегиред!</div>
              <div style={{ background: "rgba(255,255,255,0.2)", borderRadius: 10, padding: "10px 14px", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                <span style={{ color: "#fff", fontWeight: 700, fontSize: 14 }}>savdohub.tj/ref/AH234</span>
                <button onClick={copyReferral} style={{ background: "#fff", border: "none", borderRadius: 8, padding: "6px 12px", fontWeight: 700, fontSize: 11, cursor: "pointer", color: "#10B981" }}>{referralCopied ? "✓ Нусха" : "📋 Нусха"}</button>
              </div>
            </div>

            <Btn variant="ghost" onClick={() => setIsLoggedIn(false)} style={{ width: "100%", marginTop: 16, color: "#EF4444" }}>🚪 Баромадан</Btn>
          </div>
        )}

        {tab === "seller" && (
          <div>
            <div style={{ background: "linear-gradient(135deg, #3B82F6, #1D4ED8)", borderRadius: 18, padding: 20, marginBottom: 16, color: "#fff" }}>
              <div style={{ fontSize: 20, fontWeight: 900, marginBottom: 6 }}>🏪 Дӯкони худатонро кушоед!</div>
              <div style={{ fontSize: 13, opacity: 0.9, marginBottom: 14 }}>Ба миллионҳо харидорон дастрасӣ пайдо кунед</div>
              <Btn variant="secondary" style={{ borderRadius: 10 }}>+ Дӯкон кушоед</Btn>
            </div>
            <div style={{ fontWeight: 700, fontSize: 15, marginBottom: 12, color: "#1F2937" }}>📊 Имтиёзот</div>
            {[{ icon: "📱", t: "Телеграм ва Фейсбук интегратсия" }, { icon: "📹", t: "Видеоҳои маҳсулот" }, { icon: "📍", t: "Намоиш дар харита" }, { icon: "📊", t: "Аналитикаи пурра" }, { icon: "🤝", t: "Системаи таслими осон" }].map((f, i) => (
              <div key={i} style={{ display: "flex", gap: 10, padding: "12px 0", borderBottom: "1px solid #F3F4F6" }}>
                <span style={{ fontSize: 20 }}>{f.icon}</span>
                <span style={{ fontSize: 13, color: "#4B5563" }}>{f.t}</span>
              </div>
            ))}
          </div>
        )}

        {tab === "delivery" && (
          <div>
            <div style={{ fontWeight: 700, fontSize: 15, marginBottom: 14, color: "#1F2937" }}>🚚 Нархи таслим</div>
            {DELIVERY_PRICES.map((d, i) => (
              <div key={i} style={{ background: "#fff", borderRadius: 14, padding: 16, marginBottom: 10, display: "flex", justifyContent: "space-between", alignItems: "center", boxShadow: "0 2px 6px rgba(0,0,0,0.05)" }}>
                <div style={{ display: "flex", gap: 10, alignItems: "center" }}>
                  <span style={{ fontSize: 24 }}>{d.icon}</span>
                  <span style={{ fontWeight: 600, fontSize: 14 }}>{d.weight}</span>
                </div>
                <span style={{ fontWeight: 800, fontSize: 16, color: "#FF6B35" }}>{formatPrice(d.price)}</span>
              </div>
            ))}
            <div style={{ background: "#F0FDF4", borderRadius: 14, padding: 14, fontSize: 12, color: "#065F46" }}>
              🔒 Пул аввал дар SavdoHub нигоҳ дошта мешавад. Баъд аз тасдиқи харидор ба фурӯшанда мерасад.
            </div>
          </div>
        )}

        {tab === "plans" && (
          <div>
            <div style={{ textAlign: "center", marginBottom: 20 }}>
              <div style={{ fontWeight: 800, fontSize: 20, color: "#1F2937", marginBottom: 6 }}>Нақшаҳои обуна</div>
              <div style={{ fontSize: 13, color: "#6B7280" }}>Барои фурӯшандагон</div>
            </div>
            {PLANS.map((plan, i) => (
              <div key={plan.id} style={{ background: plan.id === "premium" ? `linear-gradient(135deg, #FFF8E1, #FFFDE7)` : "#fff", border: `2px solid ${plan.id === "premium" ? "#F59E0B" : "#E5E7EB"}`, borderRadius: 18, padding: 20, marginBottom: 14, position: "relative" }}>
                {plan.id === "premium" && <div style={{ position: "absolute", top: -10, left: "50%", transform: "translateX(-50%)", background: "#F59E0B", color: "#fff", borderRadius: 20, padding: "3px 16px", fontSize: 11, fontWeight: 700 }}>👑 МАЪМУЛТАРИН</div>}
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 12 }}>
                  <div>
                    <div style={{ fontWeight: 800, fontSize: 16, color: plan.color }}>{plan.name}</div>
                    <div style={{ fontSize: 11, color: "#9CA3AF" }}>{plan.id === "premium" ? "Маҳсулот беҳудуд" : `то ${plan.products} маҳсулот`}</div>
                  </div>
                  <div style={{ textAlign: "right" }}>
                    <div style={{ fontWeight: 900, fontSize: 22, color: "#1F2937" }}>{formatPrice(plan.price)}</div>
                    <div style={{ fontSize: 11, color: "#9CA3AF" }}>/ моҳ</div>
                  </div>
                </div>
                {plan.features.map((f, j) => <div key={j} style={{ fontSize: 12, color: "#4B5563", padding: "4px 0", display: "flex", gap: 8 }}><span style={{ color: "#10B981" }}>✓</span>{f}</div>)}
                <Btn onClick={() => {}} variant={plan.id === "premium" ? "primary" : "outline"} style={{ width: "100%", marginTop: 14, padding: "11px" }}>
                  {plan.id === "basic" ? "Ройгон оғоз кунед" : "Интихоб кунед"}
                </Btn>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

// ADMIN PAGE
const AdminPage = () => {
  const [tab, setTab] = useState("dashboard");
  const stats = { totalSales: 847600, orders: 1243, sellers: 89, buyers: 5420, pending: 15, revenue: { subs: 18700, delivery: 9800, ads: 12400, vip: 8200 } };

  return (
    <div style={{ paddingBottom: 80 }}>
      <div style={{ background: "linear-gradient(135deg, #1F2937, #111827)", padding: "20px 16px 16px" }}>
        <div style={{ color: "rgba(255,255,255,0.6)", fontSize: 11, marginBottom: 4 }}>🔐 МАЪМУРИЯТИ SAVDOHUB</div>
        <div style={{ fontWeight: 900, fontSize: 20, color: "#fff" }}>Панели Идора</div>
      </div>

      <div style={{ display: "flex", gap: 4, padding: "12px 16px", background: "#fff", boxShadow: "0 2px 10px rgba(0,0,0,0.05)", overflowX: "auto" }}>
        {["dashboard", "users", "orders", "earnings"].map(t => (
          <button key={t} onClick={() => setTab(t)} style={{ flexShrink: 0, border: "none", borderRadius: 20, padding: "8px 12px", fontWeight: 700, fontSize: 11, cursor: "pointer", background: tab === t ? "#1F2937" : "#F3F4F6", color: tab === t ? "#fff" : "#374151", fontFamily: "inherit" }}>
            {t === "dashboard" ? "📊 Dashboard" : t === "users" ? "👥 Корбарон" : t === "orders" ? "📦 Фармоишҳо" : "💰 Даромад"}
          </button>
        ))}
      </div>

      <div style={{ padding: 16 }}>
        {tab === "dashboard" && (
          <div>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10, marginBottom: 16 }}>
              {[{ label: "Умумии савдо", value: formatPrice(stats.totalSales), icon: "💰", color: "#10B981" }, { label: "Фармоишҳо", value: stats.orders, icon: "📦", color: "#3B82F6" }, { label: "Фурӯшандагон", value: stats.sellers, icon: "🏪", color: "#F59E0B" }, { label: "Харидорон", value: stats.buyers.toLocaleString(), icon: "👥", color: "#8B5CF6" }].map((s, i) => (
                <div key={i} style={{ background: "#fff", borderRadius: 14, padding: 14, boxShadow: "0 2px 8px rgba(0,0,0,0.06)" }}>
                  <div style={{ fontSize: 24, marginBottom: 6 }}>{s.icon}</div>
                  <div style={{ fontWeight: 800, fontSize: 16, color: s.color }}>{s.value}</div>
                  <div style={{ fontSize: 11, color: "#9CA3AF" }}>{s.label}</div>
                </div>
              ))}
            </div>
            <div style={{ background: "#fff", borderRadius: 16, padding: 16, marginBottom: 14, boxShadow: "0 2px 8px rgba(0,0,0,0.06)" }}>
              <div style={{ fontWeight: 700, fontSize: 14, marginBottom: 14 }}>📈 Манбаъҳои даромад</div>
              {[{ label: "Обунаҳои фурӯшанда", value: stats.revenue.subs, color: "#3B82F6" }, { label: "Ҳаққи таслим", value: stats.revenue.delivery, color: "#10B981" }, { label: "Реклама", value: stats.revenue.ads, color: "#F59E0B" }, { label: "VIP дӯконҳо", value: stats.revenue.vip, color: "#8B5CF6" }].map((r, i) => {
                const total = Object.values(stats.revenue).reduce((a, b) => a + b, 0);
                return (
                  <div key={i} style={{ marginBottom: 10 }}>
                    <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 4 }}>
                      <span style={{ fontSize: 12, color: "#4B5563" }}>{r.label}</span>
                      <span style={{ fontSize: 12, fontWeight: 700 }}>{formatPrice(r.value)}</span>
                    </div>
                    <div style={{ height: 8, background: "#F3F4F6", borderRadius: 4, overflow: "hidden" }}>
                      <div style={{ height: "100%", width: `${(r.value / total) * 100}%`, background: r.color, borderRadius: 4, transition: "width 0.5s" }} />
                    </div>
                  </div>
                );
              })}
            </div>
            <div style={{ background: "#FFFBEB", borderRadius: 14, padding: 14, border: "1.5px solid #F59E0B" }}>
              <div style={{ fontWeight: 700, fontSize: 14, color: "#92400E", marginBottom: 8 }}>⏳ Дар интизор ({stats.pending})</div>
              <div style={{ fontSize: 12, color: "#92400E" }}>Фурӯшандагоне, ки тасдиқро интизоранд</div>
              <Btn style={{ marginTop: 10, padding: "8px 16px", fontSize: 12 }}>Баррасӣ кунед →</Btn>
            </div>
          </div>
        )}

        {tab === "users" && (
          <div>
            <div style={{ fontWeight: 700, fontSize: 15, marginBottom: 14 }}>👥 Идораи корбарон</div>
            {SHOPS.slice(0, 5).map((shop, i) => (
              <div key={i} style={{ background: "#fff", borderRadius: 14, padding: 14, marginBottom: 10, display: "flex", gap: 10, alignItems: "center", boxShadow: "0 2px 6px rgba(0,0,0,0.05)" }}>
                <span style={{ fontSize: 28 }}>{shop.logo}</span>
                <div style={{ flex: 1 }}>
                  <div style={{ fontWeight: 700, fontSize: 13 }}>{shop.name}</div>
                  <div style={{ fontSize: 11, color: "#6B7280" }}>{shop.city} • {shop.plan}</div>
                </div>
                <div style={{ display: "flex", gap: 6 }}>
                  <button style={{ background: "#FEE2E2", border: "none", borderRadius: 8, padding: "6px 10px", color: "#EF4444", fontSize: 11, fontWeight: 700, cursor: "pointer" }}>🚫 Блок</button>
                  <button style={{ background: "#D1FAE5", border: "none", borderRadius: 8, padding: "6px 10px", color: "#10B981", fontSize: 11, fontWeight: 700, cursor: "pointer" }}>✅ OK</button>
                </div>
              </div>
            ))}
          </div>
        )}

        {tab === "orders" && (
          <div>
            <div style={{ fontWeight: 700, fontSize: 15, marginBottom: 14 }}>📦 Фармоишҳо</div>
            {ORDERS.map((o, i) => (
              <div key={i} style={{ background: "#fff", borderRadius: 14, padding: 14, marginBottom: 10, boxShadow: "0 2px 6px rgba(0,0,0,0.05)" }}>
                <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 8 }}>
                  <span style={{ fontWeight: 700, fontSize: 13 }}>{o.id}</span>
                  <span style={{ fontSize: 12, fontWeight: 700, color: "#FF6B35" }}>{formatPrice(o.total)}</span>
                </div>
                <div style={{ fontSize: 12, color: "#4B5563", marginBottom: 6 }}>{o.product}</div>
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                  <span style={{ fontSize: 11, color: "#9CA3AF" }}>{o.date}</span>
                  <span style={{ fontSize: 11, fontWeight: 700, color: getStatusColor(o.status), background: `${getStatusColor(o.status)}20`, padding: "3px 10px", borderRadius: 20 }}>{getStatusLabel(o.status)}</span>
                </div>
              </div>
            ))}
          </div>
        )}

        {tab === "earnings" && (
          <div>
            <div style={{ background: "linear-gradient(135deg, #10B981, #059669)", borderRadius: 18, padding: 20, marginBottom: 16, color: "#fff" }}>
              <div style={{ fontSize: 12, opacity: 0.8, marginBottom: 4 }}>Умумии даромад (ноябр)</div>
              <div style={{ fontWeight: 900, fontSize: 30 }}>{formatPrice(Object.values(stats.revenue).reduce((a, b) => a + b, 0))}</div>
            </div>
            {[{ label: "Обунаҳо", value: stats.revenue.subs, icon: "📊", pct: "+12%" }, { label: "Таслим", value: stats.revenue.delivery, icon: "🚚", pct: "+8%" }, { label: "Реклама", value: stats.revenue.ads, icon: "📢", pct: "+25%" }, { label: "VIP дӯконҳо", value: stats.revenue.vip, icon: "👑", pct: "+5%" }].map((e, i) => (
              <div key={i} style={{ background: "#fff", borderRadius: 14, padding: 16, marginBottom: 10, display: "flex", justifyContent: "space-between", alignItems: "center", boxShadow: "0 2px 6px rgba(0,0,0,0.05)" }}>
                <div style={{ display: "flex", gap: 12, alignItems: "center" }}>
                  <span style={{ fontSize: 24 }}>{e.icon}</span>
                  <div><div style={{ fontWeight: 600, fontSize: 14 }}>{e.label}</div><div style={{ fontSize: 11, color: "#10B981", fontWeight: 700 }}>{e.pct} ин моҳ</div></div>
                </div>
                <span style={{ fontWeight: 800, fontSize: 16, color: "#1F2937" }}>{formatPrice(e.value)}</span>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

// ============================================================
// MAIN APP
// ============================================================
export default function SavdoHub() {
  const [page, setPage] = useState("home");
  const [cart, setCart] = useState([]);
  const [openProduct, setOpenProduct] = useState(null);
  const [openShop, setOpenShop] = useState(null);
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [toast, setToast] = useState(null);

  const showToast = (msg) => { setToast(msg); setTimeout(() => setToast(null), 2500); };

  const addToCart = (product) => {
    setCart(prev => {
      const exists = prev.find(i => i.id === product.id);
      if (exists) return prev.map(i => i.id === product.id ? { ...i, qty: (i.qty || 1) + (product.qty || 1) } : i);
      return [...prev, { ...product, qty: product.qty || 1 }];
    });
    showToast(`✅ "${product.name}" ба сабад илова шуд`);
  };

  const navItems = [
    { id: "home", icon: "🏠", label: "Асосӣ" },
    { id: "catalog", icon: "🛍️", label: "Маҳсулот" },
    { id: "shops", icon: "🏪", label: "Дӯконҳо" },
    { id: "cart", icon: "🛒", label: "Сабад", badge: cart.length },
    { id: "orders", icon: "📦", label: "Фармоишҳо" },
    { id: "profile", icon: "👤", label: "Профил" },
    { id: "admin", icon: "⚙️", label: "Идора" },
  ];

  return (
    <div style={{ fontFamily: "'Segoe UI', system-ui, sans-serif", background: "#F9FAFB", minHeight: "100vh", maxWidth: 480, margin: "0 auto", position: "relative" }}>
      {/* Page Content */}
      <div style={{ minHeight: "100vh" }}>
        {page === "home" && <HomePage onOpenProduct={setOpenProduct} onAddCart={addToCart} onOpenShop={setOpenShop} setPage={setPage} />}
        {page === "catalog" && <CatalogPage onOpenProduct={setOpenProduct} onAddCart={addToCart} />}
        {page === "shops" && <ShopsPage onOpenShop={setOpenShop} />}
        {page === "cart" && <CartPage cart={cart} setCart={setCart} setPage={setPage} />}
        {page === "orders" && <OrdersPage />}
        {page === "profile" && <ProfilePage setPage={setPage} isLoggedIn={isLoggedIn} setIsLoggedIn={setIsLoggedIn} />}
        {page === "admin" && <AdminPage />}
      </div>

      {/* Bottom Navigation */}
      <div style={{ position: "fixed", bottom: 0, left: "50%", transform: "translateX(-50%)", width: "100%", maxWidth: 480, background: "#fff", borderTop: "1px solid #E5E7EB", display: "flex", padding: "8px 0 12px", boxShadow: "0 -4px 20px rgba(0,0,0,0.08)", zIndex: 100 }}>
        {navItems.map(item => (
          <button key={item.id} onClick={() => setPage(item.id)} style={{ flex: 1, border: "none", background: "none", cursor: "pointer", display: "flex", flexDirection: "column", alignItems: "center", gap: 2, position: "relative", padding: "4px 0", fontFamily: "inherit" }}>
            <span style={{ fontSize: item.id === "admin" ? 16 : 20, filter: page === item.id ? "none" : "grayscale(60%)", opacity: page === item.id ? 1 : 0.6 }}>{item.icon}</span>
            <span style={{ fontSize: 9, fontWeight: 700, color: page === item.id ? "#FF6B35" : "#9CA3AF" }}>{item.label}</span>
            {item.badge > 0 && <div style={{ position: "absolute", top: 0, right: "50%", transform: "translateX(60%)", background: "#EF4444", color: "#fff", borderRadius: "50%", width: 16, height: 16, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 9, fontWeight: 800, border: "2px solid #fff" }}>{item.badge}</div>}
            {page === item.id && <div style={{ position: "absolute", bottom: -12, width: 20, height: 3, background: "#FF6B35", borderRadius: 2 }} />}
          </button>
        ))}
      </div>

      {/* Product Modal */}
      {openProduct && <ProductDetail product={openProduct} onClose={() => setOpenProduct(null)} onAddCart={addToCart} />}

      {/* Shop Modal */}
      {openShop && (
        <Modal onClose={() => setOpenShop(null)}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 16 }}>
            <div style={{ fontWeight: 800, fontSize: 18 }}>Дӯкон</div>
            <button onClick={() => setOpenShop(null)} style={{ background: "#F3F4F6", border: "none", borderRadius: "50%", width: 36, height: 36, cursor: "pointer", fontSize: 18 }}>✕</button>
          </div>
          <div style={{ display: "flex", gap: 14, marginBottom: 16 }}>
            <div style={{ width: 64, height: 64, borderRadius: 16, background: "linear-gradient(135deg, #FFF3E0, #FFEFDF)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 34 }}>{openShop.logo}</div>
            <div>
              <div style={{ fontWeight: 800, fontSize: 18, color: "#1F2937", marginBottom: 2 }}>{openShop.name}</div>
              <div style={{ fontSize: 13, color: "#6B7280", marginBottom: 6 }}>{openShop.city}</div>
              <div style={{ display: "flex", gap: 6 }}><Tag color="#FFFBEB" textColor="#D97706">⭐ {openShop.rating}</Tag><Tag color="#F0FDF4" textColor="#10B981">✅ Тасдиқ</Tag></div>
            </div>
          </div>
          <p style={{ fontSize: 13, color: "#4B5563", marginBottom: 16, lineHeight: 1.6 }}>{openShop.description}</p>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10, marginBottom: 16 }}>
            {[{ label: "Маҳсулотҳо", value: openShop.products }, { label: "Донабинандагон", value: openShop.followers.toLocaleString() }, { label: "Нақша", value: openShop.plan }, { label: "Рейтинг", value: openShop.rating }].map((s, i) => (
              <div key={i} style={{ background: "#F9FAFB", borderRadius: 10, padding: 12 }}>
                <div style={{ fontSize: 11, color: "#9CA3AF" }}>{s.label}</div>
                <div style={{ fontWeight: 700, fontSize: 15 }}>{s.value}</div>
              </div>
            ))}
          </div>
          <div style={{ fontWeight: 700, fontSize: 14, marginBottom: 12 }}>Маҳсулотҳо</div>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 }}>
            {PRODUCTS.filter(p => p.shopId === openShop.id).map(p => <ProductCard key={p.id} product={p} onOpen={(pr) => { setOpenShop(null); setOpenProduct(pr); }} onAddCart={addToCart} compact />)}
          </div>
        </Modal>
      )}

      {/* Toast */}
      {toast && (
        <div style={{ position: "fixed", bottom: 80, left: "50%", transform: "translateX(-50%)", background: "#1F2937", color: "#fff", borderRadius: 14, padding: "12px 20px", fontSize: 13, fontWeight: 600, boxShadow: "0 8px 24px rgba(0,0,0,0.2)", zIndex: 200, whiteSpace: "nowrap", animation: "fadeIn 0.2s" }}>
          {toast}
        </div>
      )}

      <style>{`* { box-sizing: border-box; } body { margin: 0; } @keyframes fadeIn { from { opacity: 0; transform: translateX(-50%) translateY(8px); } to { opacity: 1; transform: translateX(-50%) translateY(0); } } ::-webkit-scrollbar { width: 0; height: 0; }`}</style>
    </div>
  );
}
