const express = require('express');
const router = express.Router();
const User = require('../models/User');
const Order = require('../models/Order');
const auth = require('../middleware/auth');
const { adminOnly } = require('../middleware/auth');

// GET /api/users/profile
router.get('/profile', auth, async (req, res) => {
  try {
    const user = await User.findById(req.user.id).select('-password').populate('shopId');
    const orderCount = await Order.countDocuments({ buyer: req.user.id });
    res.json({ success: true, user, orderCount });
  } catch (err) {
    res.status(500).json({ message: 'Сервер хатогӣ' });
  }
});

// PUT /api/users/profile
router.put('/profile', auth, async (req, res) => {
  try {
    const { name, email, address, city } = req.body;
    const user = await User.findByIdAndUpdate(
      req.user.id, { name, email, address, city }, { new: true }
    ).select('-password');
    res.json({ success: true, user });
  } catch (err) {
    res.status(500).json({ message: 'Сервер хатогӣ' });
  }
});

// GET /api/users/admin/all - Admin only
router.get('/admin/all', auth, adminOnly, async (req, res) => {
  try {
    const users = await User.find().select('-password').sort({ createdAt: -1 });
    res.json({ success: true, users });
  } catch (err) {
    res.status(500).json({ message: 'Сервер хатогӣ' });
  }
});

// PUT /api/users/admin/:id/block - Admin block user
router.put('/admin/:id/block', auth, adminOnly, async (req, res) => {
  try {
    const user = await User.findByIdAndUpdate(
      req.params.id, { isActive: false }, { new: true }
    ).select('-password');
    res.json({ success: true, user });
  } catch (err) {
    res.status(500).json({ message: 'Сервер хатогӣ' });
  }
});

module.exports = router;
