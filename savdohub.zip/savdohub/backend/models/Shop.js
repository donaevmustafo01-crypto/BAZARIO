const mongoose = require('mongoose');

const shopSchema = new mongoose.Schema({
  name: { type: String, required: true, trim: true },
  description: { type: String, default: '' },
  logo: { type: String, default: '🏪' },
  banner: { type: String, default: '' },
  owner: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  city: { type: String, default: 'Душанбе' },
  address: { type: String, default: '' },
  phone: { type: String, default: '' },
  plan: { type: String, enum: ['basic', 'standard', 'premium'], default: 'basic' },
  planExpiresAt: { type: Date },
  isActive: { type: Boolean, default: false }, // Admin activates after payment
  isVerified: { type: Boolean, default: false },
  rating: { type: Number, default: 0 },
  totalRatings: { type: Number, default: 0 },
  followers: [{ type: mongoose.Schema.Types.ObjectId, ref: 'User' }],
  totalSales: { type: Number, default: 0 },
  categories: [{ type: String }],
  socialLinks: {
    telegram: { type: String, default: '' },
    instagram: { type: String, default: '' },
    facebook: { type: String, default: '' },
  },
  paymentDetails: {
    cardNumber: { type: String, default: '' },
    cardHolder: { type: String, default: '' },
    bankName: { type: String, default: '' },
  },
}, { timestamps: true });

// Virtual: products count
shopSchema.virtual('productCount', {
  ref: 'Product',
  localField: '_id',
  foreignField: 'shop',
  count: true
});

module.exports = mongoose.model('Shop', shopSchema);
