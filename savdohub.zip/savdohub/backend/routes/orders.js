const express = require('express');
const router = express.Router();
const Order = require('../models/Order');
const Product = require('../models/Product');
const auth = require('../middleware/auth');
const { adminOnly } = require('../middleware/auth');

// Delivery fee calculator
const calcDeliveryFee = (weight) => {
  if (weight <= 1) return 15;
  if (weight <= 3) return 25;
  if (weight <= 5) return 35;
  return 50;
};

// POST /api/orders - Create order
router.post('/', auth, async (req, res) => {
  try {
    const { items, deliveryAddress, paymentMethod, notes } = req.body;

    if (!items || items.length === 0) {
      return res.status(400).json({ message: 'Сабад холӣ аст' });
    }

    // Validate products and calculate totals
    let totalAmount = 0;
    let totalWeight = 0;
    const orderItems = [];

    for (const item of items) {
      const product = await Product.findById(item.productId).populate('shop');
      if (!product) return res.status(404).json({ message: `Маҳсулот ёфт нашуд` });
      if (product.stock < item.quantity) {
        return res.status(400).json({ message: `"${product.name}" захираи кофӣ нест` });
      }

      orderItems.push({
        product: product._id,
        shop: product.shop._id,
        name: product.name,
        price: product.price,
        quantity: item.quantity,
        emoji: product.emoji,
      });

      totalAmount += product.price * item.quantity;
      totalWeight += product.weight * item.quantity;

      // Reduce stock
      product.stock -= item.quantity;
      product.sold += item.quantity;
      await product.save();
    }

    const deliveryFee = calcDeliveryFee(totalWeight);

    const order = await Order.create({
      buyer: req.user.id,
      items: orderItems,
      totalAmount,
      deliveryFee,
      totalWeight,
      deliveryAddress,
      paymentMethod: paymentMethod || 'cod',
      notes,
      statusHistory: [{ status: 'ordered', note: 'Фармоиш қабул шуд' }],
    });

    res.status(201).json({ success: true, order });
  } catch (err) {
    res.status(500).json({ message: 'Сервер хатогӣ', error: err.message });
  }
});

// GET /api/orders/my - My orders
router.get('/my', auth, async (req, res) => {
  try {
    const orders = await Order.find({ buyer: req.user.id })
      .sort({ createdAt: -1 })
      .populate('items.product', 'name emoji images');
    res.json({ success: true, orders });
  } catch (err) {
    res.status(500).json({ message: 'Сервер хатогӣ' });
  }
});

// GET /api/orders/shop - Seller's shop orders
router.get('/shop', auth, async (req, res) => {
  try {
    const orders = await Order.find({ 'items.shop': req.user.shopId })
      .sort({ createdAt: -1 })
      .populate('buyer', 'name phone');
    res.json({ success: true, orders });
  } catch (err) {
    res.status(500).json({ message: 'Сервер хатогӣ' });
  }
});

// PUT /api/orders/:id/status - Update order status
router.put('/:id/status', auth, async (req, res) => {
  try {
    const { status, note } = req.body;
    const order = await Order.findById(req.params.id);
    if (!order) return res.status(404).json({ message: 'Ёфт нашуд' });

    order.status = status;
    order.statusHistory.push({ status, note: note || '' });

    // Release escrow when delivered
    if (status === 'delivered') {
      order.escrowReleased = true;
      order.paymentStatus = 'paid';
    }

    await order.save();
    res.json({ success: true, order });
  } catch (err) {
    res.status(500).json({ message: 'Сервер хатогӣ' });
  }
});

// GET /api/orders/admin/all - Admin: all orders
router.get('/admin/all', auth, adminOnly, async (req, res) => {
  try {
    const { status, page = 1, limit = 20 } = req.query;
    const filter = status ? { status } : {};
    const orders = await Order.find(filter)
      .sort({ createdAt: -1 })
      .skip((page - 1) * limit).limit(Number(limit))
      .populate('buyer', 'name phone');
    const total = await Order.countDocuments(filter);
    res.json({ success: true, orders, total });
  } catch (err) {
    res.status(500).json({ message: 'Сервер хатогӣ' });
  }
});

module.exports = router;
