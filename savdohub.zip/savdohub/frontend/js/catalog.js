// CATALOG
let catFilter = 'all';
let catPage = 1;
let catTotal = 0;

function setCatFilter(cat, btn) {
  catFilter = cat;
  catPage = 1;
  if (btn) {
    document.querySelectorAll('#cat-filter-chips .chip').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
  }
  loadCatalog();
}

async function loadCatalog() {
  catPage = 1;
  const sort = document.getElementById('sort-select')?.value || 'pop';
  const grid = document.getElementById('catalog-grid');
  if (!grid) return;
  grid.innerHTML = '<div class="loading" style="grid-column:1/-1"><div class="spinner"></div></div>';

  try {
    const url = `/products?category=${catFilter}&sort=${sort}&page=1&limit=12`;
    const { products, total } = await GET(url);
    catTotal = total;
    document.getElementById('cat-count').textContent = `${total} маҳсулот ёфт шуд`;
    grid.innerHTML = products.length ? products.map(p => pcardHTML(p)).join('') : '<div class="empty-state" style="grid-column:1/-1"><div class="empty-ico">😕</div><div>Маҳсулот ёфт нашуд</div></div>';
    document.getElementById('load-more-btn').style.display = total > 12 ? 'block' : 'none';
  } catch (e) {
    grid.innerHTML = '<div class="empty-state" style="grid-column:1/-1"><div class="empty-ico">⚠️</div><div>Хатогӣ юз дод</div></div>';
  }
}

async function loadMoreProducts() {
  catPage++;
  const sort = document.getElementById('sort-select')?.value || 'pop';
  try {
    const { products } = await GET(`/products?category=${catFilter}&sort=${sort}&page=${catPage}&limit=12`);
    const grid = document.getElementById('catalog-grid');
    grid.innerHTML += products.map(p => pcardHTML(p)).join('');
    if (catPage * 12 >= catTotal) document.getElementById('load-more-btn').style.display = 'none';
  } catch (e) { showToast('Хатогӣ', 'error'); }
}
