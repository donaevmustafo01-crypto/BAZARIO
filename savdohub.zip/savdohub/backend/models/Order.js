const mongoose = require('mongoose');

const orderItemSchema = new mongoose.Schema({
  product: { type: mongoose.Schema.Types.ObjectId, ref: 'Product', required: true },
  shop: { type: mongoose.Schema.Types.ObjectId, ref: 'Shop', required: true },
  name: { type: String, required: true },
  price: { type: Number, required: true },
  quantity: { type: Number, required: true, default: 1 },
  emoji: { type: String, default: '📦' },
});

const orderSchema = new mongoose.Schema({
  orderNumber: { type: String, unique: true },
  buyer: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  items: [orderItemSchema],
  totalAmount: { type: Number, required: true },
  deliveryFee: { type: Number, default: 15 },
  totalWeight: { type: Number, default: 0 },

  status: {
    type: String,
    enum: ['ordered', 'processing', 'shipped', 'delivered', 'cancelled'],
    default: 'ordered'
  },

  paymentMethod: {
    type: String,
    enum: ['cod', 'card', 'wallet'],
    default: 'cod'
  },
  paymentStatus: {
    type: String,
    enum: ['pending', 'paid', 'refunded'],
    default: 'pending'
  },

  deliveryAddress: {
    city: { type: String, required: true },
    street: { type: String, required: true },
    house: { type: String },
    phone: { type: String, required: true },
  },

  notes: { type: String, default: '' },

  statusHistory: [{
    status: String,
    date: { type: Date, default: Date.now },
    note: String
  }],

  escrowReleased: { type: Boolean, default: false },
  confirmedByBuyer: { type: Boolean, default: false },
}, { timestamps: true });

// Generate order number
orderSchema.pre('save', function(next) {
  if (!this.orderNumber) {
    const date = new Date();
    const year = date.getFullYear();
    const random = Math.floor(Math.random() * 10000).toString().padStart(4, '0');
    this.orderNumber = `SH-${year}-${random}`;
  }
  next();
});

module.exports = mongoose.model('Order', orderSchema);
