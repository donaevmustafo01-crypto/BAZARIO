const express = require('express');
const router = express.Router();
const Shop = require('../models/Shop');
const User = require('../models/User');
const auth = require('../middleware/auth');
const { adminOnly, sellerOnly } = require('../middleware/auth');

// GET /api/shops
router.get('/', async (req, res) => {
  try {
    const { plan, search, city, limit = 20, page = 1 } = req.query;
    const filter = { isActive: true };
    if (plan && plan !== 'all') filter.plan = plan;
    if (city) filter.city = city;
    if (search) filter.name = { $regex: search, $options: 'i' };

    const shops = await Shop.find(filter)
      .sort({ plan: -1, rating: -1 })
      .skip((page - 1) * limit).limit(Number(limit))
      .populate('owner', 'name phone');

    const total = await Shop.countDocuments(filter);
    res.json({ success: true, shops, total });
  } catch (err) {
    res.status(500).json({ message: 'Сервер хатогӣ' });
  }
});

// GET /api/shops/:id
router.get('/:id', async (req, res) => {
  try {
    const shop = await Shop.findById(req.params.id).populate('owner', 'name phone');
    if (!shop) return res.status(404).json({ message: 'Дӯкон ёфт нашуд' });
    res.json({ success: true, shop });
  } catch (err) {
    res.status(500).json({ message: 'Сервер хатогӣ' });
  }
});

// POST /api/shops - Create shop (registered users)
router.post('/', auth, async (req, res) => {
  try {
    const existing = await Shop.findOne({ owner: req.user.id });
    if (existing) return res.status(400).json({ message: 'Шумо аллакай дӯкон доред' });

    const shop = await Shop.create({ ...req.body, owner: req.user.id, isActive: false });

    // Update user role
    await User.findByIdAndUpdate(req.user.id, { role: 'seller', shopId: shop._id });

    res.status(201).json({
      success: true,
      shop,
      message: 'Дӯкон сохта шуд. Баъд аз пардохти обуна фаъол мешавад.'
    });
  } catch (err) {
    res.status(500).json({ message: 'Сервер хатогӣ', error: err.message });
  }
});

// PUT /api/shops/:id - Update shop
router.put('/:id', auth, async (req, res) => {
  try {
    const shop = await Shop.findById(req.params.id);
    if (!shop) return res.status(404).json({ message: 'Ёфт нашуд' });
    if (shop.owner.toString() !== req.user.id && req.user.role !== 'admin') {
      return res.status(403).json({ message: 'Иҷозат нест' });
    }
    const updated = await Shop.findByIdAndUpdate(req.params.id, req.body, { new: true });
    res.json({ success: true, shop: updated });
  } catch (err) {
    res.status(500).json({ message: 'Сервер хатогӣ' });
  }
});

// POST /api/shops/:id/activate - Admin activates shop after payment
router.post('/:id/activate', auth, adminOnly, async (req, res) => {
  try {
    const { plan } = req.body;
    const planDays = { basic: 30, standard: 30, premium: 30 };
    const expiresAt = new Date();
    expiresAt.setDate(expiresAt.getDate() + planDays[plan]);

    const shop = await Shop.findByIdAndUpdate(req.params.id, {
      isActive: true, plan, planExpiresAt: expiresAt, isVerified: true
    }, { new: true });

    res.json({ success: true, shop, message: 'Дӯкон фаъол шуд!' });
  } catch (err) {
    res.status(500).json({ message: 'Сервер хатогӣ' });
  }
});

// POST /api/shops/:id/follow
router.post('/:id/follow', auth, async (req, res) => {
  try {
    const shop = await Shop.findById(req.params.id);
    if (!shop) return res.status(404).json({ message: 'Ёфт нашуд' });

    const idx = shop.followers.indexOf(req.user.id);
    if (idx > -1) shop.followers.splice(idx, 1);
    else shop.followers.push(req.user.id);
    await shop.save();

    res.json({ success: true, following: idx === -1, followers: shop.followers.length });
  } catch (err) {
    res.status(500).json({ message: 'Сервер хатогӣ' });
  }
});

// GET /api/shops/pending - Admin: pending shops
router.get('/admin/pending', auth, adminOnly, async (req, res) => {
  try {
    const shops = await Shop.find({ isActive: false }).populate('owner', 'name phone');
    res.json({ success: true, shops });
  } catch (err) {
    res.status(500).json({ message: 'Сервер хатогӣ' });
  }
});

module.exports = router;
