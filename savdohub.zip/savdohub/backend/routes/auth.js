const express = require('express');
const router = express.Router();
const jwt = require('jsonwebtoken');
const User = require('../models/User');
const auth = require('../middleware/auth');

// Generate JWT token
const generateToken = (id) => {
  return jwt.sign({ id }, process.env.JWT_SECRET, { expiresIn: '30d' });
};

// @route POST /api/auth/register
router.post('/register', async (req, res) => {
  try {
    const { name, phone, password, referralCode } = req.body;

    if (!name || !phone || !password) {
      return res.status(400).json({ message: 'Ҳама майдонҳоро пур кунед' });
    }

    const exists = await User.findOne({ phone });
    if (exists) {
      return res.status(400).json({ message: 'Ин рақами телефон аллакай қайд шудааст' });
    }

    // Check referral
    let referredBy = null;
    if (referralCode) {
      const referrer = await User.findOne({ referralCode });
      if (referrer) {
        referredBy = referrer._id;
        referrer.bonusPoints += 5;
        await referrer.save();
      }
    }

    const user = await User.create({ name, phone, password, referredBy });
    if (referredBy) { user.bonusPoints = 5; await user.save(); }

    res.status(201).json({
      success: true,
      token: generateToken(user._id),
      user: { id: user._id, name: user.name, phone: user.phone, role: user.role, bonusPoints: user.bonusPoints, referralCode: user.referralCode }
    });
  } catch (err) {
    res.status(500).json({ message: 'Сервер хатогӣ', error: err.message });
  }
});

// @route POST /api/auth/login
router.post('/login', async (req, res) => {
  try {
    const { phone, password } = req.body;

    if (!phone || !password) {
      return res.status(400).json({ message: 'Телефон ва паролро ворид кунед' });
    }

    const user = await User.findOne({ phone }).populate('shopId');
    if (!user) return res.status(401).json({ message: 'Корбар ёфт нашуд' });

    const isMatch = await user.comparePassword(password);
    if (!isMatch) return res.status(401).json({ message: 'Парол нодуруст аст' });

    if (!user.isActive) return res.status(403).json({ message: 'Ҳисоби шумо бандӣ шудааст' });

    res.json({
      success: true,
      token: generateToken(user._id),
      user: {
        id: user._id, name: user.name, phone: user.phone,
        role: user.role, bonusPoints: user.bonusPoints,
        referralCode: user.referralCode, shopId: user.shopId
      }
    });
  } catch (err) {
    res.status(500).json({ message: 'Сервер хатогӣ', error: err.message });
  }
});

// @route GET /api/auth/me
router.get('/me', auth, async (req, res) => {
  try {
    const user = await User.findById(req.user.id).select('-password').populate('shopId');
    res.json({ success: true, user });
  } catch (err) {
    res.status(500).json({ message: 'Сервер хатогӣ' });
  }
});

module.exports = router;
