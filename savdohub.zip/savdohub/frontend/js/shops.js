// SHOPS
let shopPlanFilter = 'all';

function setShopFilter(plan, btn) {
  shopPlanFilter = plan;
  document.querySelectorAll('#page-shops .chip').forEach(b => b.classList.remove('active'));
  if (btn) btn.classList.add('active');
  loadShops();
}

async function loadShops(search = '') {
  const list = document.getElementById('shops-list');
  if (!list) return;
  list.innerHTML = '<div class="loading"><div class="spinner"></div></div>';
  try {
    const url = `/shops?plan=${shopPlanFilter}&search=${encodeURIComponent(search)}&limit=20`;
    const { shops } = await GET(url);
    list.innerHTML = shops.length ? shops.map(s => scardHTML(s)).join('') : '<div class="empty-state"><div class="empty-ico">🏪</div><div>Дӯкон ёфт нашуд</div></div>';
  } catch (e) {
    list.innerHTML = '<div class="empty-state"><div class="empty-ico">⚠️</div><div>Хатогӣ</div></div>';
  }
}

async function openShop(id) {
  const modal = document.getElementById('prod-modal');
  const content = document.getElementById('prod-modal-content');
  content.innerHTML = '<div class="loading" style="height:200px"><div class="spinner"></div></div>';
  modal.classList.add('open');

  try {
    const { shop } = await GET(`/shops/${id}`);
    const { products } = await GET(`/products?shop=${id}&limit=10`);
    const planLbl = shop.plan === 'premium' ? '👑 Премиум' : shop.plan === 'standard' ? '⭐ Стандартӣ' : 'Базавӣ';

    content.innerHTML = `
      <div class="modal-head">
        <div class="modal-title">Дӯкон</div>
        <button class="modal-close" onclick="document.getElementById('prod-modal').classList.remove('open')">✕</button>
      </div>
      <div style="display:flex;gap:12px;margin-bottom:14px">
        <div style="width:60px;height:60px;border-radius:14px;background:#FFF3E0;display:flex;align-items:center;justify-content:center;font-size:30px">${shop.logo || '🏪'}</div>
        <div>
          <div style="font-weight:900;font-size:17px">${shop.name} ${shop.isVerified ? '✅' : ''}</div>
          <div style="font-size:12px;color:#6B7280;margin-bottom:5px">${shop.city}</div>
          <div style="display:flex;gap:5px">
            <span style="background:#FFF3E0;color:#FF5722;font-size:10px;font-weight:800;padding:2px 8px;border-radius:20px">⭐ ${(shop.rating||0).toFixed(1)}</span>
            <span style="background:#F3F4F6;color:#6B7280;font-size:10px;font-weight:800;padding:2px 8px;border-radius:20px">${planLbl}</span>
          </div>
        </div>
      </div>
      <p style="font-size:13px;color:#4B5563;margin-bottom:14px;line-height:1.6">${shop.description || ''}</p>
      ${shop.socialLinks?.telegram ? `<a href="${shop.socialLinks.telegram}" style="display:inline-block;background:#2196F3;color:#fff;border-radius:10px;padding:7px 14px;font-size:12px;font-weight:800;text-decoration:none;margin-bottom:14px">📱 Телеграм</a>` : ''}
      <div style="font-weight:800;font-size:14px;margin-bottom:10px">Маҳсулотҳо (${products.length})</div>
      <div class="grid2">${products.map(p => pcardHTML(p)).join('')}</div>
    `;
  } catch (e) {
    content.innerHTML = `<div class="modal-head"><div class="modal-title">Хатогӣ</div><button class="modal-close" onclick="document.getElementById('prod-modal').classList.remove('open')">✕</button></div><p style="padding:20px;color:#9CA3AF">Бор нашуд</p>`;
  }
}
