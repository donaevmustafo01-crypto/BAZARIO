// API Configuration
const API_URL = window.location.hostname === 'localhost'
  ? 'http://localhost:5000/api'
  : '/api';

// Token management
const getToken = () => localStorage.getItem('savdohub_token');
const setToken = (t) => localStorage.setItem('savdohub_token', t);
const removeToken = () => localStorage.removeItem('savdohub_token');

// Current user
let currentUser = null;

// HTTP helper
async function api(method, endpoint, data = null, auth = false) {
  const headers = { 'Content-Type': 'application/json' };
  if (auth) {
    const token = getToken();
    if (token) headers['Authorization'] = `Bearer ${token}`;
  }

  const config = { method, headers };
  if (data) config.body = JSON.stringify(data);

  const res = await fetch(`${API_URL}${endpoint}`, config);
  const json = await res.json();

  if (!res.ok) throw new Error(json.message || 'Хатогӣ');
  return json;
}

const GET = (url, auth = false) => api('GET', url, null, auth);
const POST = (url, data, auth = false) => api('POST', url, data, auth);
const PUT = (url, data, auth = false) => api('PUT', url, data, auth);
const DELETE = (url, auth = false) => api('DELETE', url, null, auth);

// Load current user on page load
async function loadCurrentUser() {
  const token = getToken();
  if (!token) return;
  try {
    const { user } = await GET('/auth/me', true);
    currentUser = user;
    updateAuthUI();
  } catch (e) {
    removeToken();
    currentUser = null;
  }
}

function updateAuthUI() {
  const profileBtn = document.getElementById('nav-profile');
  if (currentUser && profileBtn) {
    // Update profile nav
  }
}

// Format price
const fmt = (p) => Number(p).toLocaleString('ru-TJ') + ' сом.';
const stars = (r) => '★'.repeat(Math.round(r || 0)) + '☆'.repeat(5 - Math.round(r || 0));
const disc = (p) => p.originalPrice ? Math.round((1 - p.price / p.originalPrice) * 100) : 0;

// Toast notification
function showToast(msg, type = 'success') {
  const t = document.getElementById('toast');
  t.textContent = msg;
  t.style.background = type === 'error' ? '#EF4444' : '#1F2937';
  t.style.display = 'block';
  setTimeout(() => t.style.display = 'none', 2800);
}

// Cart (local storage)
let cart = JSON.parse(localStorage.getItem('savdohub_cart') || '[]');

function saveCart() {
  localStorage.setItem('savdohub_cart', JSON.stringify(cart));
  updateCartBadge();
}

function addToCart(product) {
  const ex = cart.find(i => i._id === product._id);
  if (ex) ex.qty += (product.qty || 1);
  else cart.push({ ...product, qty: product.qty || 1 });
  saveCart();
  showToast(`✅ "${product.name}" ба сабад илова шуд`);
}

function updateCartBadge() {
  const total = cart.reduce((s, i) => s + i.qty, 0);
  const badge = document.getElementById('cart-badge');
  if (!badge) return;
  if (total > 0) { badge.style.display = 'flex'; badge.textContent = total; }
  else badge.style.display = 'none';
}

// Page navigation
function goPage(id) {
  document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
  const page = document.getElementById('page-' + id);
  if (page) page.classList.add('active');

  document.querySelectorAll('.nav-btn').forEach(b => {
    b.classList.remove('active');
    const dot = b.querySelector('.nav-dot');
    if (dot) dot.remove();
  });
  const nb = document.getElementById('nav-' + id);
  if (nb) {
    nb.classList.add('active');
    const d = document.createElement('div');
    d.className = 'nav-dot';
    nb.appendChild(d);
  }

  // Load page content
  const loaders = {
    catalog: loadCatalog,
    shops: loadShops,
    cart: renderCart,
    orders: loadOrders,
    profile: renderProfile,
    admin: renderAdmin,
  };
  if (loaders[id]) loaders[id]();
}
