const express = require('express');
const router = express.Router();
const Product = require('../models/Product');
const Shop = require('../models/Shop');
const auth = require('../middleware/auth');
const { sellerOnly } = require('../middleware/auth');

// GET /api/products - Get all products with filters
router.get('/', async (req, res) => {
  try {
    const { category, search, sort, shop, limit = 20, page = 1 } = req.query;
    const filter = { isActive: true };

    if (category && category !== 'all') filter.category = category;
    if (shop) filter.shop = shop;
    if (search) filter.$text = { $search: search };

    let sortObj = {};
    if (sort === 'asc') sortObj.price = 1;
    else if (sort === 'desc') sortObj.price = -1;
    else sortObj.sold = -1;

    const skip = (page - 1) * limit;
    const products = await Product.find(filter)
      .sort(sortObj).skip(skip).limit(Number(limit))
      .populate('shop', 'name logo city rating');

    const total = await Product.countDocuments(filter);

    res.json({ success: true, products, total, pages: Math.ceil(total / limit) });
  } catch (err) {
    res.status(500).json({ message: 'Сервер хатогӣ', error: err.message });
  }
});

// GET /api/products/:id
router.get('/:id', async (req, res) => {
  try {
    const product = await Product.findById(req.params.id)
      .populate('shop', 'name logo city rating isVerified phone socialLinks')
      .populate('reviews.user', 'name avatar');

    if (!product) return res.status(404).json({ message: 'Маҳсулот ёфт нашуд' });

    product.views += 1;
    await product.save();

    res.json({ success: true, product });
  } catch (err) {
    res.status(500).json({ message: 'Сервер хатогӣ' });
  }
});

// POST /api/products - Create product (seller only)
router.post('/', auth, sellerOnly, async (req, res) => {
  try {
    const shop = await Shop.findOne({ owner: req.user.id, isActive: true });
    if (!shop) return res.status(403).json({ message: 'Фаъол дӯкон надоред' });

    // Check plan limits
    const productCount = await Product.countDocuments({ shop: shop._id });
    const limits = { basic: 20, standard: 100, premium: Infinity };
    if (productCount >= limits[shop.plan]) {
      return res.status(403).json({ message: `Нақшаи ${shop.plan} ҳадди ${limits[shop.plan]} маҳсулотро иҷоза медиҳад` });
    }

    const product = await Product.create({ ...req.body, shop: shop._id });
    res.status(201).json({ success: true, product });
  } catch (err) {
    res.status(500).json({ message: 'Сервер хатогӣ', error: err.message });
  }
});

// PUT /api/products/:id - Update product
router.put('/:id', auth, sellerOnly, async (req, res) => {
  try {
    const product = await Product.findById(req.params.id).populate('shop');
    if (!product) return res.status(404).json({ message: 'Ёфт нашуд' });
    if (product.shop.owner.toString() !== req.user.id && req.user.role !== 'admin') {
      return res.status(403).json({ message: 'Иҷозат нест' });
    }
    const updated = await Product.findByIdAndUpdate(req.params.id, req.body, { new: true });
    res.json({ success: true, product: updated });
  } catch (err) {
    res.status(500).json({ message: 'Сервер хатогӣ' });
  }
});

// DELETE /api/products/:id
router.delete('/:id', auth, sellerOnly, async (req, res) => {
  try {
    const product = await Product.findById(req.params.id).populate('shop');
    if (!product) return res.status(404).json({ message: 'Ёфт нашуд' });
    if (product.shop.owner.toString() !== req.user.id && req.user.role !== 'admin') {
      return res.status(403).json({ message: 'Иҷозат нест' });
    }
    await product.deleteOne();
    res.json({ success: true, message: 'Маҳсулот нест шуд' });
  } catch (err) {
    res.status(500).json({ message: 'Сервер хатогӣ' });
  }
});

// POST /api/products/:id/review - Add review
router.post('/:id/review', auth, async (req, res) => {
  try {
    const { rating, comment } = req.body;
    const product = await Product.findById(req.params.id);
    if (!product) return res.status(404).json({ message: 'Ёфт нашуд' });

    const alreadyReviewed = product.reviews.find(r => r.user.toString() === req.user.id);
    if (alreadyReviewed) return res.status(400).json({ message: 'Шумо аллакай шарҳ навиштед' });

    product.reviews.push({ user: req.user.id, rating, comment });
    product.calcRating();
    await product.save();

    res.json({ success: true, message: 'Шарҳ илова шуд' });
  } catch (err) {
    res.status(500).json({ message: 'Сервер хатогӣ' });
  }
});

module.exports = router;
