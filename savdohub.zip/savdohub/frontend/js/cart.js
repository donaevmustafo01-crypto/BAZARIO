// CART
function renderCart() {
  const cc = document.getElementById('cart-content');
  const ct = document.getElementById('cart-title');
  if (!cc) return;
  if (ct) ct.textContent = `🛒 Сабад (${cart.length})`;

  if (!cart.length) {
    cc.innerHTML = `<div class="empty-state"><div class="empty-ico">🛒</div><div style="font-weight:900;font-size:18px;margin-bottom:8px">Сабад холӣ аст</div><div style="font-size:13px;margin-bottom:22px">Маҳсулот илова кунед</div><button onclick="goPage('catalog')" class="btn-primary" style="max-width:200px;margin:0 auto">🛍️ Харид кун</button></div>`;
    return;
  }

  const tot = cart.reduce((s, i) => s + i.price * i.qty, 0);
  const wt = cart.reduce((s, i) => s + (i.weight || 0.5) * i.qty, 0);
  const dp = wt <= 1 ? 15 : wt <= 3 ? 25 : wt <= 5 ? 35 : 50;

  cc.innerHTML = `
    ${cart.map(item => `
      <div class="cart-item">
        <div style="width:56px;height:56px;border-radius:12px;background:#FFF8F0;display:flex;align-items:center;justify-content:center;font-size:28px;flex-shrink:0">${item.emoji || '📦'}</div>
        <div style="flex:1;min-width:0">
          <div style="font-weight:700;font-size:13px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${item.name}</div>
          <div style="font-weight:900;color:#FF5722;font-size:14px">${fmt(item.price)}</div>
          <div style="display:flex;align-items:center;gap:8px;margin-top:6px">
            <button onclick="cartQty('${item._id}',-1)" style="width:26px;height:26px;border-radius:8px;border:1.5px solid #E5E7EB;background:#fff;font-weight:900;cursor:pointer">−</button>
            <span style="font-weight:800;font-size:14px">${item.qty}</span>
            <button onclick="cartQty('${item._id}',1)" style="width:26px;height:26px;border-radius:8px;border:1.5px solid #FF5722;background:#FFF3E0;color:#FF5722;font-weight:900;cursor:pointer">+</button>
          </div>
        </div>
        <button onclick="cartRemove('${item._id}')" style="background:#FEE2E2;border:none;border-radius:10px;width:34px;height:34px;cursor:pointer;color:#EF4444;font-size:15px;flex-shrink:0">🗑️</button>
      </div>`).join('')}
    <div style="background:#F0FDF4;border-radius:14px;padding:12px;margin-bottom:12px">
      <div style="font-weight:800;font-size:13px;color:#065F46;margin-bottom:6px">🚚 Таслим</div>
      <div style="display:flex;justify-content:space-between;font-size:12px;color:#6B7280">
        <span>Вазн: ${wt.toFixed(1)}кг</span>
        <span style="font-weight:800;color:#10B981">${fmt(dp)}</span>
      </div>
    </div>
    <div style="background:#fff;border-radius:16px;padding:14px;box-shadow:0 2px 8px rgba(0,0,0,.06);margin-bottom:14px">
      <div style="display:flex;justify-content:space-between;font-size:13px;color:#6B7280;margin-bottom:8px"><span>Маҳсулот</span><span>${fmt(tot)}</span></div>
      <div style="display:flex;justify-content:space-between;font-size:13px;color:#6B7280;margin-bottom:12px"><span>Таслим</span><span>${fmt(dp)}</span></div>
      <div style="border-top:1.5px dashed #E5E7EB;padding-top:12px;display:flex;justify-content:space-between;font-weight:900;font-size:16px">
        <span>Ҷамъ</span><span style="color:#FF5722">${fmt(tot + dp)}</span>
      </div>
    </div>
    <button onclick="showCheckout(${tot},${dp})" class="btn-primary">Фармоиш додан →</button>
  `;
}

function cartQty(id, d) {
  const i = cart.find(x => x._id === id);
  if (i) { i.qty = Math.max(1, i.qty + d); saveCart(); renderCart(); }
}
function cartRemove(id) {
  cart = cart.filter(x => x._id !== id);
  saveCart(); renderCart();
}

function showCheckout(tot, dp) {
  if (!currentUser) { showAuthModal('login'); return; }
  const cc = document.getElementById('cart-content');
  cc.innerHTML = `
    <div style="background:#fff;border-radius:16px;padding:14px;margin-bottom:12px;box-shadow:0 2px 8px rgba(0,0,0,.06)">
      <div style="font-weight:900;font-size:14px;margin-bottom:12px">📋 Суроғаи таслим</div>
      <input id="co-city" class="form-input" placeholder="Шаҳр" value="${currentUser.city || 'Душанбе'}">
      <input id="co-street" class="form-input" placeholder="Кӯча ва хона">
      <input id="co-phone" class="form-input" placeholder="Телефон" value="${currentUser.phone || ''}">
    </div>
    <div style="background:#fff;border-radius:16px;padding:14px;margin-bottom:12px;box-shadow:0 2px 8px rgba(0,0,0,.06)">
      <div style="font-weight:900;font-size:14px;margin-bottom:12px">💳 Усули пардохт</div>
      ${[{id:'cod',l:'💵 Пул дар таслим',d:'Баъд аз гирифтан'},{id:'card',l:'💳 Корти бонкӣ',d:'Visa, Mastercard, SOMONI'},{id:'wallet',l:'📱 ALIF Pay',d:'Ҳамёни рақамӣ'}]
        .map((m, i) => `<div class="pay-opt ${i===0?'selected':''}" onclick="selectPay(this)" data-pay="${m.id}">
          <div style="width:20px;height:20px;border-radius:50%;border:2px solid ${i===0?'#FF5722':'#D1D5DB'};display:flex;align-items:center;justify-content:center;flex-shrink:0;margin-top:2px" id="radio-${m.id}">
            ${i===0?'<div style="width:10px;height:10px;border-radius:50%;background:#FF5722"></div>':''}
          </div>
          <div><div style="font-weight:800;font-size:13px">${m.l}</div><div style="font-size:11px;color:#6B7280">${m.d}</div></div>
        </div>`).join('')}
    </div>
    <div style="background:#FFFBEB;border-radius:12px;padding:12px;margin-bottom:14px;font-size:12px;color:#92400E">🔒 Пул аввал дар SavdoHub нигоҳ дошта мешавад</div>
    <div style="display:flex;gap:10px">
      <button onclick="renderCart()" class="btn-secondary" style="max-width:120px">← Бозгашт</button>
      <button onclick="confirmOrder(${tot+dp})" class="btn-primary">✅ Тасдиқ (${fmt(tot+dp)})</button>
    </div>
  `;
}

function selectPay(el) {
  document.querySelectorAll('.pay-opt').forEach(o => { o.classList.remove('selected'); o.style.borderColor = '#E5E7EB'; o.style.background = '#fff'; });
  el.classList.add('selected');
  el.style.borderColor = '#FF5722';
  el.style.background = '#FFF8F4';
}

async function confirmOrder(total) {
  const city = document.getElementById('co-city')?.value;
  const street = document.getElementById('co-street')?.value;
  const phone = document.getElementById('co-phone')?.value;
  const payEl = document.querySelector('.pay-opt.selected');
  const paymentMethod = payEl?.dataset.pay || 'cod';

  if (!city || !street || !phone) { showToast('⚠️ Ҳама майдонҳоро пур кунед', 'error'); return; }

  const btn = event.target;
  btn.textContent = '⏳ Фиристода мешавад...';
  btn.disabled = true;

  try {
    const items = cart.map(i => ({ productId: i._id, quantity: i.qty }));
    await POST('/orders', {
      items,
      deliveryAddress: { city, street, phone },
      paymentMethod,
    }, true);

    cart = []; saveCart();
    document.getElementById('cart-content').innerHTML = `
      <div class="empty-state" style="padding-top:60px">
        <div class="empty-ico" style="font-size:80px">🎉</div>
        <div style="font-weight:900;font-size:22px;margin-bottom:8px;color:#1F2937">Фармоиш қабул шуд!</div>
        <div style="font-size:14px;margin-bottom:24px">Мо зуд бо шумо тамос мегирем</div>
        <button onclick="goPage('orders')" class="btn-primary" style="max-width:220px;margin:0 auto">📦 Фармоишҳоро бин</button>
      </div>`;
  } catch (e) {
    showToast(e.message || 'Хатогӣ', 'error');
    btn.textContent = `✅ Тасдиқ (${fmt(total)})`;
    btn.disabled = false;
  }
}
