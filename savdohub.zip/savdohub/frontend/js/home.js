// HOME PAGE

const CATEGORIES = [
  { id: 'electronics', name: 'Электроника', emoji: '📱' },
  { id: 'clothing', name: 'Либос', emoji: '👗' },
  { id: 'home', name: 'Хона', emoji: '🏠' },
  { id: 'toys', name: 'Бозичаҳо', emoji: '🧸' },
  { id: 'auto', name: 'Авто', emoji: '🚗' },
  { id: 'food', name: 'Ғизо', emoji: '🍎' },
  { id: 'sports', name: 'Варзиш', emoji: '⚽' },
  { id: 'other', name: 'Дигар', emoji: '📦' },
];

async function loadHome() {
  // Render categories
  const cg = document.getElementById('cats-grid');
  if (cg) {
    cg.innerHTML = CATEGORIES.map(c =>
      `<div class="cat" onclick="setCatFilter('${c.id}',null);goPage('catalog')">
        <div class="cat-ico">${c.emoji}</div>
        <div class="cat-name">${c.name}</div>
      </div>`
    ).join('');
  }

  // Load trending products
  try {
    const { products } = await GET('/products?sort=pop&limit=6');
    const tg = document.getElementById('trending-grid');
    if (tg) tg.innerHTML = products.map(p => pcardHTML(p)).join('');
  } catch (e) {
    document.getElementById('trending-grid').innerHTML = '<p style="color:#9CA3AF;font-size:12px;padding:10px">Маҳсулот бор нашуд</p>';
  }

  // Load featured shops
  try {
    const { shops } = await GET('/shops?plan=premium&limit=3');
    const fs = document.getElementById('featured-shops');
    if (fs) fs.innerHTML = shops.length ? shops.map(s => scardHTML(s)).join('') : '<p style="color:#9CA3AF;font-size:12px;padding:10px">Дӯкон ёфт нашуд</p>';
  } catch (e) {
    document.getElementById('featured-shops').innerHTML = '<p style="color:#9CA3AF;font-size:12px;padding:10px">Дӯкон бор нашуд</p>';
  }
}

// Product card HTML
function pcardHTML(p) {
  const d = disc(p);
  const img = p.images && p.images[0] ? `<img src="${p.images[0]}" style="width:100%;height:100%;object-fit:cover">` : (p.emoji || '📦');
  return `<div class="pcard" onclick="openProduct('${p._id}')">
    <div class="pcard-img">
      ${typeof img === 'string' && img.startsWith('<img') ? img : `<span style="font-size:52px">${img}</span>`}
      ${d > 0 ? `<div class="pcard-disc">-${d}%</div>` : ''}
      ${p.badge ? `<div class="pcard-badge">${p.badge}</div>` : ''}
      <button class="pcard-like" onclick="event.stopPropagation();this.textContent=this.textContent==='🤍'?'❤️':'🤍'">🤍</button>
    </div>
    <div class="pcard-body">
      <div class="pcard-name">${p.name}</div>
      <div class="pcard-stars">${stars(p.rating)} <span style="color:#9CA3AF;font-size:10px">(${p.reviews?.length || 0})</span></div>
      <div><span class="pcard-price">${fmt(p.price)}</span>${p.originalPrice ? `<span class="pcard-orig">${fmt(p.originalPrice)}</span>` : ''}</div>
      <button class="pcard-btn" onclick="event.stopPropagation();addToCart({...${JSON.stringify({_id:p._id,name:p.name,price:p.price,emoji:p.emoji||'📦',weight:p.weight||0.5})}})">🛒 Ба сабад</button>
    </div>
  </div>`;
}

// Shop card HTML
function scardHTML(s) {
  const planLbl = s.plan === 'premium' ? '👑 Премиум' : s.plan === 'standard' ? '⭐ Стандартӣ' : 'Базавӣ';
  const planClr = s.plan === 'premium' ? 'background:#FFFBEB;color:#D97706' : s.plan === 'standard' ? 'background:#EFF6FF;color:#3B82F6' : 'background:#F9FAFB;color:#6B7280';
  return `<div class="scard" onclick="openShop('${s._id}')">
    <div class="scard-top">
      <div class="scard-logo">${s.logo || '🏪'}</div>
      <div style="flex:1;min-width:0">
        <div style="font-weight:800;font-size:14px">${s.name} ${s.isVerified ? '✅' : ''}</div>
        <div style="font-size:11px;color:#6B7280">${s.city}</div>
      </div>
      <div style="text-align:right;font-size:12px;font-weight:800;color:#F59E0B">⭐ ${(s.rating || 0).toFixed(1)}</div>
    </div>
    <div style="font-size:12px;color:#6B7280;margin-bottom:8px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${s.description}</div>
    <div style="display:flex;justify-content:space-between;align-items:center">
      <span style="font-size:10px;font-weight:800;padding:2px 9px;border-radius:20px;${planClr}">${planLbl}</span>
      <span style="font-size:11px;color:#9CA3AF">👥 ${(s.followers?.length || 0).toLocaleString()}</span>
    </div>
  </div>`;
}

// Search
let searchTimeout;
function doSearch(val) {
  clearTimeout(searchTimeout);
  const sr = document.getElementById('search-results');
  const mh = document.getElementById('main-home');
  if (!val.trim()) {
    sr.style.display = 'none';
    mh.style.display = 'block';
    return;
  }
  sr.style.display = 'block';
  mh.style.display = 'none';
  sr.innerHTML = '<div class="loading"><div class="spinner"></div></div>';
  searchTimeout = setTimeout(async () => {
    try {
      const { products } = await GET(`/products?search=${encodeURIComponent(val)}&limit=20`);
      sr.innerHTML = `<div style="font-weight:900;font-size:15px;margin:14px 0 12px">Натиҷаҳо: "${val}"</div>
        <div class="grid2">${products.map(p => pcardHTML(p)).join('')}</div>
        ${products.length === 0 ? '<div class="empty-state"><div class="empty-ico">😕</div><div>Ёфт нашуд</div></div>' : ''}`;
    } catch (e) {
      sr.innerHTML = '<div class="empty-state"><div class="empty-ico">⚠️</div><div>Хатогӣ</div></div>';
    }
  }, 400);
}

// Open product modal
async function openProduct(id) {
  const modal = document.getElementById('prod-modal');
  const content = document.getElementById('prod-modal-content');
  content.innerHTML = '<div class="loading" style="height:200px"><div class="spinner"></div></div>';
  modal.classList.add('open');
  modal.querySelector = modal.querySelector.bind(modal);

  try {
    const { product } = await GET(`/products/${id}`);
    renderProductModal(product);
  } catch (e) {
    content.innerHTML = `<div class="modal-head"><div class="modal-title">Хатогӣ</div><button class="modal-close" onclick="document.getElementById('prod-modal').classList.remove('open')">✕</button></div><p style="color:#9CA3AF;padding:20px">Маҳсулот бор нашуд</p>`;
  }
}

let currentProd = null;
let currentQty = 1;

function renderProductModal(p) {
  currentProd = p;
  currentQty = 1;
  const d = disc(p);
  const shop = p.shop;
  const content = document.getElementById('prod-modal-content');
  content.innerHTML = `
    <div class="modal-head">
      <div class="modal-title">Маҳсулот</div>
      <button class="modal-close" onclick="document.getElementById('prod-modal').classList.remove('open')">✕</button>
    </div>
    <div style="height:180px;background:linear-gradient(135deg,#FFF8F0,#FFEFDF);border-radius:16px;display:flex;align-items:center;justify-content:center;font-size:80px;margin-bottom:14px;position:relative">
      ${p.emoji || '📦'}
      ${d > 0 ? `<div style="position:absolute;top:10px;left:10px;background:#EF4444;color:#fff;border-radius:8px;padding:3px 9px;font-size:11px;font-weight:800">-${d}%</div>` : ''}
    </div>
    <div style="font-weight:900;font-size:18px;margin-bottom:6px">${p.name}</div>
    <div style="display:flex;align-items:center;gap:7px;margin-bottom:10px;flex-wrap:wrap">
      <span style="color:#F59E0B">${stars(p.rating)}</span>
      <span style="font-size:12px;color:#6B7280">${p.reviews?.length || 0} шарҳ</span>
      ${p.badge ? `<span style="background:#F59E0B;color:#fff;font-size:10px;font-weight:800;padding:2px 8px;border-radius:20px">${p.badge}</span>` : ''}
      <span style="background:#EFF6FF;color:#3B82F6;font-size:10px;font-weight:800;padding:2px 8px;border-radius:20px">📦 ${p.weight}кг</span>
    </div>
    <div id="modal-price-display" style="margin-bottom:14px">
      <span style="font-size:24px;font-weight:900;color:#FF5722">${fmt(p.price)}</span>
      ${p.originalPrice ? `<span style="font-size:14px;color:#9CA3AF;text-decoration:line-through;margin-left:10px">${fmt(p.originalPrice)}</span>` : ''}
    </div>
    <div class="modal-tabs">
      <button class="modal-tab active" onclick="mTab('minfo',this)">ℹ️ Маълумот</button>
      <button class="modal-tab" onclick="mTab('mshop',this)">🏪 Дӯкон</button>
      <button class="modal-tab" onclick="mTab('mreviews',this)">⭐ Шарҳ</button>
    </div>
    <div id="minfo" class="tab-content active">
      <p style="font-size:13px;color:#4B5563;line-height:1.6;margin-bottom:12px">${p.description}</p>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px">
        <div style="background:#F9FAFB;border-radius:10px;padding:10px"><div style="font-size:10px;color:#9CA3AF">Вазн</div><div style="font-weight:700">${p.weight}кг</div></div>
        <div style="background:#F9FAFB;border-radius:10px;padding:10px"><div style="font-size:10px;color:#9CA3AF">Захира</div><div style="font-weight:700">${p.stock} дона</div></div>
      </div>
    </div>
    <div id="mshop" class="tab-content">
      ${shop ? `<div style="background:#F9FAFB;border-radius:12px;padding:12px">
        <div style="display:flex;align-items:center;gap:10px;margin-bottom:8px">
          <div style="font-size:32px">${shop.logo || '🏪'}</div>
          <div><div style="font-weight:700;font-size:14px">${shop.name}</div><div style="font-size:11px;color:#6B7280">${shop.city}</div></div>
        </div>
        <div style="font-size:12px;color:#4B5563">${shop.description || ''}</div>
        <button onclick="document.getElementById('prod-modal').classList.remove('open');openShop('${shop._id}')" style="margin-top:10px;background:#FF5722;color:#fff;border:none;border-radius:10px;padding:8px 16px;font-weight:800;font-size:12px;cursor:pointer;font-family:inherit">Дӯконро бин →</button>
      </div>` : '<p style="color:#9CA3AF;font-size:13px">Маълумот нест</p>'}
    </div>
    <div id="mreviews" class="tab-content">
      ${p.reviews && p.reviews.length > 0
        ? p.reviews.slice(0,3).map(r => `<div style="background:#F9FAFB;border-radius:12px;padding:12px;margin-bottom:8px">
            <div style="display:flex;justify-content:space-between;margin-bottom:3px">
              <span style="font-weight:800;font-size:13px">${r.user?.name || 'Корбар'}</span>
              <span style="font-size:10px;color:#9CA3AF">${new Date(r.createdAt).toLocaleDateString('ru-RU')}</span>
            </div>
            <div style="color:#F59E0B;font-size:12px">${stars(r.rating)}</div>
            <p style="font-size:12px;color:#6B7280;margin-top:4px">${r.comment || ''}</p>
          </div>`).join('')
        : '<div class="empty-state" style="padding:20px"><div class="empty-ico" style="font-size:36px">💬</div><div style="font-size:13px">Шарҳе нест</div></div>'}
      ${currentUser ? `<button onclick="showAddReview('${p._id}')" style="width:100%;margin-top:8px;background:#F3F4F6;border:none;border-radius:12px;padding:10px;font-weight:800;font-size:13px;cursor:pointer;font-family:inherit">+ Шарҳ нависед</button>` : ''}
    </div>
    <div style="display:flex;align-items:center;gap:10px;margin-top:14px">
      <div style="display:flex;align-items:center;gap:8px;background:#F3F4F6;border-radius:12px;padding:6px 12px">
        <button onclick="changeModalQty(-1)" style="background:none;border:none;font-weight:900;font-size:18px;cursor:pointer;color:#FF5722">−</button>
        <span id="modal-qty-val" style="font-weight:900;font-size:15px;min-width:20px;text-align:center">1</span>
        <button onclick="changeModalQty(1)" style="background:none;border:none;font-weight:900;font-size:18px;cursor:pointer;color:#FF5722">+</button>
      </div>
      <button id="modal-cart-btn" onclick="modalAddToCart()" style="flex:1;background:linear-gradient(135deg,#FF5722,#FF7043);color:#fff;border:none;border-radius:12px;padding:12px;font-weight:800;font-size:13px;cursor:pointer;font-family:inherit">🛒 Ба сабад (${fmt(p.price)})</button>
    </div>
  `;
}

function mTab(id, btn) {
  document.querySelectorAll('.modal-tab').forEach(t => t.classList.remove('active'));
  document.querySelectorAll('.tab-content').forEach(t => t.classList.remove('active'));
  btn.classList.add('active');
  document.getElementById(id).classList.add('active');
}

function changeModalQty(d) {
  currentQty = Math.max(1, currentQty + d);
  document.getElementById('modal-qty-val').textContent = currentQty;
  if (currentProd) {
    document.getElementById('modal-price-display').innerHTML = `<span style="font-size:24px;font-weight:900;color:#FF5722">${fmt(currentProd.price * currentQty)}</span>`;
    document.getElementById('modal-cart-btn').textContent = `🛒 Ба сабад (${fmt(currentProd.price * currentQty)})`;
  }
}

function modalAddToCart() {
  if (!currentProd) return;
  addToCart({ _id: currentProd._id, name: currentProd.name, price: currentProd.price, emoji: currentProd.emoji || '📦', weight: currentProd.weight || 0.5, qty: currentQty });
  document.getElementById('prod-modal').classList.remove('open');
}
