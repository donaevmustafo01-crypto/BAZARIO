# SavdoHub — Бозори Тоҷикистон 🇹🇯

Marketplace барои Тоҷикистон: харидор, фурӯшанда, admin.

## Сохтор
```
savdohub/
├── backend/          ← Node.js + Express + MongoDB
│   ├── server.js
│   ├── models/       ← User, Shop, Product, Order
│   ├── routes/       ← API endpoints
│   └── middleware/   ← auth, roles
├── frontend/         ← HTML/CSS/JS (GitHub Pages)
│   ├── index.html
│   └── js/
└── render.yaml       ← Deploy config
```

## Deploy кардан

### 1. MongoDB Atlas (Database)
1. mongodb.com/atlas → Create free account
2. Create cluster → Free tier
3. Database Access → Add user (username + password)
4. Network Access → Add IP: 0.0.0.0/0
5. Connect → Driver → Copy connection string

### 2. Render.com (Backend)
1. render.com → Sign up with GitHub
2. New → Web Service → Connect savdohub repo
3. Root Directory: `backend`
4. Build: `npm install`
5. Start: `npm start`
6. Environment Variables:
   - `MONGODB_URI` = mongodb+srv://...
   - `JWT_SECRET` = savdohub_2024_secret
   - `NODE_ENV` = production
7. Deploy!

### 3. GitHub Pages (Frontend)
1. frontend/js/api.js дар API_URL-ро ивоз кун:
   ```
   const API_URL = 'https://YOUR-APP.onrender.com/api';
   ```
2. frontend/ файлҳоро ба GitHub Pages бор кун

## Admin ҳисоб
MongoDB-да дастӣ role-ро 'admin' кун:
```js
db.users.updateOne({phone: "+992..."}, {$set: {role: "admin"}})
```

## API Endpoints
- POST /api/auth/register
- POST /api/auth/login
- GET  /api/products
- POST /api/products (seller)
- GET  /api/shops
- POST /api/orders (buyer)
- GET  /api/orders/my (buyer)
