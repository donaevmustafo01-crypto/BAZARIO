const mongoose = require('mongoose');

const reviewSchema = new mongoose.Schema({
  user: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  rating: { type: Number, required: true, min: 1, max: 5 },
  comment: { type: String, trim: true },
  createdAt: { type: Date, default: Date.now }
});

const productSchema = new mongoose.Schema({
  name: { type: String, required: true, trim: true },
  description: { type: String, required: true },
  price: { type: Number, required: true, min: 0 },
  originalPrice: { type: Number },
  category: { type: String, required: true },
  shop: { type: mongoose.Schema.Types.ObjectId, ref: 'Shop', required: true },
  images: [{ type: String }],
  emoji: { type: String, default: '📦' },
  stock: { type: Number, required: true, default: 0 },
  weight: { type: Number, default: 0.5 }, // kg
  badge: { type: String, enum: ['ТОП', 'БЕСТСЕЛЛЕР', 'НАРХ ПАСТ', 'МАЪМУЛ', 'VIP', 'ТОЗА', null], default: null },
  hasVideo: { type: Boolean, default: false },
  videoUrl: { type: String, default: '' },
  isActive: { type: Boolean, default: true },
  views: { type: Number, default: 0 },
  sold: { type: Number, default: 0 },
  reviews: [reviewSchema],
  rating: { type: Number, default: 0 },
  tags: [{ type: String }],
  specifications: [{
    key: { type: String },
    value: { type: String }
  }],
}, { timestamps: true });

// Calculate average rating
productSchema.methods.calcRating = function() {
  if (this.reviews.length === 0) { this.rating = 0; return; }
  this.rating = this.reviews.reduce((acc, r) => acc + r.rating, 0) / this.reviews.length;
};

// Text search index
productSchema.index({ name: 'text', description: 'text', tags: 'text' });

module.exports = mongoose.model('Product', productSchema);
