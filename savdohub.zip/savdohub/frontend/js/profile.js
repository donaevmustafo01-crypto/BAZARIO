// ORDERS
async function loadOrders() {
  const list = document.getElementById('orders-list');
  if (!list) return;
  if (!currentUser) {
    list.innerHTML = `<div class="empty-state"><div class="empty-ico">🔒</div><div style="font-weight:900;margin-bottom:10px">Ворид шавед</div><button onclick="showAuthModal('login')" class="btn-primary" style="max-width:180px;margin:0 auto">Ворид шудан</button></div>`;
    return;
  }
  list.innerHTML = '<div class="loading"><div class="spinner"></div></div>';
  try {
    const { orders } = await GET('/orders/my', true);
    if (!orders.length) {
      list.innerHTML = '<div class="empty-state"><div class="empty-ico">📦</div><div>Фармоише нест</div></div>';
      return;
    }
    const steps = ['ordered','processing','shipped','delivered'];
    const lbls = ['Фармоиш','Коркард','Равона','Расид'];
    const icos = ['📋','⚙️','🚚','✅'];
    list.innerHTML = orders.map(o => {
      const cur = steps.indexOf(o.status);
      return `<div class="otrack">
        <div style="display:flex;align-items:center;gap:10px;margin-bottom:14px">
          <span style="font-size:26px">📦</span>
          <div><div style="font-weight:700;font-size:14px">${o.orderNumber}</div><div style="font-size:11px;color:#6B7280">${new Date(o.createdAt).toLocaleDateString('ru-RU')}</div></div>
          <div style="margin-left:auto;font-weight:800;color:#FF5722;font-size:13px">${fmt(o.totalAmount + o.deliveryFee)}</div>
        </div>
        <div class="otrack-steps">
          ${steps.map((s, i) => `<div class="ostep">
            ${i < steps.length-1 ? `<div class="ostep-line" style="background:${i < cur ? '#10B981' : '#E5E7EB'}"></div>` : ''}
            <div class="ostep-circle" style="background:${i <= cur ? '#10B981' : '#E5E7EB'}">${icos[i]}</div>
            <div class="ostep-lbl" style="color:${i <= cur ? '#10B981' : '#9CA3AF'}">${lbls[i]}</div>
          </div>`).join('')}
        </div>
      </div>`;
    }).join('');
  } catch (e) {
    list.innerHTML = '<div class="empty-state"><div class="empty-ico">⚠️</div><div>Хатогӣ</div></div>';
  }
}

// PROFILE
function renderProfile() {
  const pc = document.getElementById('profile-content');
  if (!pc) return;
  if (!currentUser) {
    pc.innerHTML = `
      <div style="padding:32px 20px 100px;text-align:center">
        <div style="font-size:80px;margin-bottom:16px">👤</div>
        <div style="font-weight:900;font-size:22px;margin-bottom:8px">Хуш омадед!</div>
        <div style="font-size:13px;color:#6B7280;margin-bottom:28px">Барои хариди осон ворид шавед</div>
        <div style="display:flex;flex-direction:column;gap:10px;max-width:320px;margin:0 auto">
          <button onclick="showAuthModal('login')" class="btn-primary">🔑 Ворид шавед</button>
          <button onclick="showAuthModal('register')" class="btn-secondary">📝 Қайд шавед</button>
        </div>
      </div>`;
    return;
  }
  pc.innerHTML = `
    <div style="background:linear-gradient(135deg,#FF5722,#FF7043);padding:22px 16px 28px">
      <div style="display:flex;align-items:center;gap:12px">
        <div style="width:62px;height:62px;border-radius:50%;background:rgba(255,255,255,.2);display:flex;align-items:center;justify-content:center;font-size:28px;border:3px solid rgba(255,255,255,.4)">👤</div>
        <div>
          <div style="font-weight:900;font-size:17px;color:#fff">${currentUser.name}</div>
          <div style="font-size:12px;color:rgba(255,255,255,.8)">${currentUser.phone}</div>
          <span style="background:rgba(255,255,255,.2);color:#fff;font-size:10px;font-weight:800;padding:2px 8px;border-radius:20px;margin-top:4px;display:inline-block">${currentUser.role === 'admin' ? '⚙️ Админ' : currentUser.role === 'seller' ? '🏪 Фурӯшанда' : '🛍️ Харидор'}</span>
        </div>
      </div>
      <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:8px;margin-top:14px">
        ${[{l:'Бонус',v:`${currentUser.bonusPoints} сом.`,i:'🎁'},{l:'Реферал',v:currentUser.referralCode,i:'🔗'},{l:'Нақш',v:currentUser.role,i:'👑'}]
          .map(s => `<div style="background:rgba(255,255,255,.18);border-radius:12px;padding:10px 6px;text-align:center">
            <div style="font-size:18px;margin-bottom:2px">${s.i}</div>
            <div style="font-weight:900;font-size:11px;color:#fff">${s.v}</div>
            <div style="font-size:9px;color:rgba(255,255,255,.8)">${s.l}</div>
          </div>`).join('')}
      </div>
    </div>
    <div style="padding:14px">
      ${currentUser.role === 'seller' || currentUser.role === 'admin' ? `
        <button onclick="goPage('${currentUser.role === 'admin' ? 'admin' : 'seller'}')" style="width:100%;background:linear-gradient(135deg,#1565C0,#0D47A1);color:#fff;border:none;border-radius:14px;padding:14px;font-weight:800;font-size:14px;cursor:pointer;font-family:inherit;margin-bottom:12px">
          ${currentUser.role === 'admin' ? '⚙️ Панели Admin' : '🏪 Панели Фурӯшанда'}
        </button>` : `
        <button onclick="showCreateShop()" style="width:100%;background:linear-gradient(135deg,#3B82F6,#1D4ED8);color:#fff;border:none;border-radius:14px;padding:14px;font-weight:800;font-size:14px;cursor:pointer;font-family:inherit;margin-bottom:12px">
          🏪 Дӯкон кушоед
        </button>`}
      ${[{i:'📦',l:'Фармоишҳо',a:"goPage('orders')"},{i:'❤️',l:'Дӯстдоштаҳо'},{i:'📍',l:'Суроғаҳо'},{i:'⚙️',l:'Танзимот'}]
        .map(m => `<div style="background:#fff;border-radius:14px;padding:14px 16px;margin-bottom:8px;display:flex;justify-content:space-between;align-items:center;box-shadow:0 2px 6px rgba(0,0,0,.05);cursor:pointer" ${m.a ? `onclick="${m.a}"` : ''}>
          <div style="display:flex;gap:10px;align-items:center"><span style="font-size:18px">${m.i}</span><span style="font-weight:700;font-size:14px">${m.l}</span></div>
          <span style="color:#D1D5DB;font-size:18px">›</span>
        </div>`).join('')}
      <button onclick="logout()" style="width:100%;margin-top:8px;background:none;border:none;color:#EF4444;font-weight:800;font-size:14px;cursor:pointer;padding:12px;font-family:inherit">🚪 Баромадан</button>
    </div>`;
}

// AUTH MODAL
function showAuthModal(type) {
  const modal = document.getElementById('auth-modal');
  const content = document.getElementById('auth-modal-content');
  modal.classList.add('open');

  if (type === 'login') {
    content.innerHTML = `
      <div class="modal-head">
        <div class="modal-title">🔑 Ворид шавед</div>
        <button class="modal-close" onclick="document.getElementById('auth-modal').classList.remove('open')">✕</button>
      </div>
      <input id="auth-phone" class="form-input" placeholder="Рақами телефон (+992...)" type="tel">
      <input id="auth-pass" class="form-input" placeholder="Парол" type="password">
      <button onclick="doLogin()" class="btn-primary" style="margin-bottom:12px">Ворид шудан</button>
      <button onclick="showAuthModal('register')" class="btn-secondary">Ҳисоб надоред? Қайд шавед</button>`;
  } else {
    content.innerHTML = `
      <div class="modal-head">
        <div class="modal-title">📝 Қайд шавед</div>
        <button class="modal-close" onclick="document.getElementById('auth-modal').classList.remove('open')">✕</button>
      </div>
      <input id="reg-name" class="form-input" placeholder="Номи пурра">
      <input id="reg-phone" class="form-input" placeholder="Рақами телефон (+992...)" type="tel">
      <input id="reg-pass" class="form-input" placeholder="Парол (ҳадди ақал 6 рақам)" type="password">
      <input id="reg-ref" class="form-input" placeholder="Коди даъватнома (ихтиёрӣ)" style="margin-bottom:16px">
      <button onclick="doRegister()" class="btn-primary" style="margin-bottom:12px">Қайд шудан</button>
      <button onclick="showAuthModal('login')" class="btn-secondary">Ҳисоб доред? Ворид шавед</button>`;
  }
}

async function doLogin() {
  const phone = document.getElementById('auth-phone').value;
  const password = document.getElementById('auth-pass').value;
  try {
    const { token, user } = await POST('/auth/login', { phone, password });
    setToken(token);
    currentUser = user;
    document.getElementById('auth-modal').classList.remove('open');
    showToast('✅ Хуш омадед, ' + user.name + '!');
    renderProfile();
  } catch (e) { showToast(e.message, 'error'); }
}

async function doRegister() {
  const name = document.getElementById('reg-name').value;
  const phone = document.getElementById('reg-phone').value;
  const password = document.getElementById('reg-pass').value;
  const referralCode = document.getElementById('reg-ref').value;
  try {
    const { token, user } = await POST('/auth/register', { name, phone, password, referralCode });
    setToken(token);
    currentUser = user;
    document.getElementById('auth-modal').classList.remove('open');
    showToast('🎉 Хуш омадед, ' + user.name + '!');
    renderProfile();
  } catch (e) { showToast(e.message, 'error'); }
}

function logout() {
  removeToken();
  currentUser = null;
  cart = []; saveCart();
  showToast('👋 Хайр!');
  renderProfile();
}

// CREATE SHOP
function showCreateShop() {
  if (!currentUser) { showAuthModal('login'); return; }
  const modal = document.getElementById('auth-modal');
  const content = document.getElementById('auth-modal-content');
  modal.classList.add('open');
  content.innerHTML = `
    <div class="modal-head">
      <div class="modal-title">🏪 Дӯкон кушоед</div>
      <button class="modal-close" onclick="document.getElementById('auth-modal').classList.remove('open')">✕</button>
    </div>
    <input id="shop-name" class="form-input" placeholder="Номи дӯкон">
    <input id="shop-city" class="form-input" placeholder="Шаҳр" value="Душанбе">
    <input id="shop-phone" class="form-input" placeholder="Телефони дӯкон">
    <textarea id="shop-desc" class="form-input" placeholder="Тавсифи дӯкон" rows="3" style="resize:none"></textarea>
    <div style="background:#FFFBEB;border-radius:12px;padding:12px;margin-bottom:14px;font-size:12px;color:#92400E">
      💳 Баъд аз сохтан, барои фаъол кардан пардохт фиристед:<br>
      <strong>9000 0000 0000 0000 • ALIF Bank</strong>
    </div>
    <button onclick="createShop()" class="btn-primary">🏪 Дӯкон сохтан</button>`;
}

async function createShop() {
  const name = document.getElementById('shop-name').value;
  const city = document.getElementById('shop-city').value;
  const phone = document.getElementById('shop-phone').value;
  const description = document.getElementById('shop-desc').value;
  if (!name) { showToast('Номи дӯконро ворид кунед', 'error'); return; }
  try {
    await POST('/shops', { name, city, phone, description }, true);
    await loadCurrentUser();
    document.getElementById('auth-modal').classList.remove('open');
    showToast('✅ Дӯкон сохта шуд! Баъд аз пардохт фаъол мешавад.');
    renderProfile();
  } catch (e) { showToast(e.message, 'error'); }
}

// ADMIN
async function renderAdmin() {
  if (!currentUser || currentUser.role !== 'admin') {
    document.getElementById('admin-content').innerHTML = '<div class="empty-state"><div class="empty-ico">🔒</div><div>Танҳо Admin</div></div>';
    return;
  }
  adminTab('dash', document.querySelector('#page-admin .chip'));
}

function adminTab(id, btn) {
  document.querySelectorAll('#page-admin .chip').forEach(b => { b.classList.remove('active'); b.style.background = '#F3F4F6'; b.style.color = '#374151'; });
  if (btn) { btn.classList.add('active'); btn.style.background = '#1F2937'; btn.style.color = '#fff'; }
  loadAdminTab(id);
}

async function loadAdminTab(id) {
  const ac = document.getElementById('admin-content');
  ac.innerHTML = '<div class="loading"><div class="spinner"></div></div>';

  if (id === 'dash') {
    try {
      const [usersRes, shopsRes, ordersRes] = await Promise.all([
        GET('/users/admin/all', true),
        GET('/shops', true),
        GET('/orders/admin/all', true),
      ]);
      ac.innerHTML = `
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-bottom:14px">
          ${[{l:'Корбарон',v:usersRes.users.length,i:'👥',c:'#3B82F6'},
            {l:'Дӯконҳо',v:shopsRes.total,i:'🏪',c:'#F59E0B'},
            {l:'Фармоишҳо',v:ordersRes.total,i:'📦',c:'#10B981'},
            {l:'Интизор',v:shopsRes.shops?.filter(s=>!s.isActive).length||0,i:'⏳',c:'#EF4444'}]
            .map(s => `<div class="stat-card"><div style="font-size:22px;margin-bottom:6px">${s.i}</div><div style="font-weight:900;font-size:20px;color:${s.c}">${s.v}</div><div style="font-size:11px;color:#9CA3AF">${s.l}</div></div>`).join('')}
        </div>`;
    } catch (e) { ac.innerHTML = '<div class="empty-state"><div class="empty-ico">⚠️</div><div>Бор нашуд</div></div>'; }
  } else if (id === 'shops') {
    try {
      const { shops } = await GET('/shops/admin/pending', true);
      ac.innerHTML = `<div style="font-weight:900;font-size:14px;margin-bottom:12px">⏳ Интизори тасдиқ (${shops.length})</div>` +
        (shops.length ? shops.map(s => `
          <div style="background:#fff;border-radius:14px;padding:12px;margin-bottom:10px;box-shadow:0 2px 6px rgba(0,0,0,.05)">
            <div style="font-weight:800;font-size:14px;margin-bottom:4px">${s.name}</div>
            <div style="font-size:12px;color:#6B7280;margin-bottom:8px">${s.owner?.name} • ${s.owner?.phone}</div>
            <div style="display:flex;gap:6px">
              ${['basic','standard','premium'].map(plan => `
                <button onclick="activateShop('${s._id}','${plan}')" style="flex:1;background:${plan==='premium'?'#FF5722':plan==='standard'?'#3B82F6':'#6B7280'};color:#fff;border:none;border-radius:8px;padding:6px 4px;font-weight:800;font-size:10px;cursor:pointer;font-family:inherit">${plan}</button>
              `).join('')}
            </div>
          </div>`).join('')
        : '<div class="empty-state"><div class="empty-ico">✅</div><div>Ҳама тасдиқ шуд</div></div>');
    } catch (e) { ac.innerHTML = '<div class="empty-state"><div>Бор нашуд</div></div>'; }
  } else if (id === 'orders') {
    try {
      const { orders } = await GET('/orders/admin/all', true);
      ac.innerHTML = `<div style="font-weight:900;font-size:14px;margin-bottom:12px">📦 Ҳама фармоишҳо</div>` +
        orders.map(o => `<div style="background:#fff;border-radius:14px;padding:12px;margin-bottom:10px;box-shadow:0 2px 6px rgba(0,0,0,.05)">
          <div style="display:flex;justify-content:space-between;margin-bottom:4px"><span style="font-weight:800">${o.orderNumber}</span><span style="color:#FF5722;font-weight:800">${fmt(o.totalAmount)}</span></div>
          <div style="font-size:12px;color:#6B7280">${o.buyer?.name} • ${o.buyer?.phone}</div>
          <div style="font-size:11px;font-weight:800;color:#10B981;margin-top:4px">${o.status}</div>
        </div>`).join('');
    } catch (e) { ac.innerHTML = '<div class="empty-state"><div>Бор нашуд</div></div>'; }
  } else if (id === 'users') {
    try {
      const { users } = await GET('/users/admin/all', true);
      ac.innerHTML = `<div style="font-weight:900;font-size:14px;margin-bottom:12px">👥 Корбарон (${users.length})</div>` +
        users.slice(0,20).map(u => `<div style="background:#fff;border-radius:14px;padding:12px;margin-bottom:8px;display:flex;justify-content:space-between;align-items:center;box-shadow:0 2px 6px rgba(0,0,0,.05)">
          <div><div style="font-weight:700">${u.name}</div><div style="font-size:11px;color:#6B7280">${u.phone} • ${u.role}</div></div>
          <button onclick="blockUser('${u._id}')" style="background:#FEE2E2;border:none;border-radius:8px;padding:5px 10px;color:#EF4444;font-size:11px;font-weight:800;cursor:pointer">Блок</button>
        </div>`).join('');
    } catch (e) { ac.innerHTML = '<div class="empty-state"><div>Бор нашуд</div></div>'; }
  }
}

async function activateShop(id, plan) {
  try {
    await POST(`/shops/${id}/activate`, { plan }, true);
    showToast('✅ Дӯкон фаъол шуд!');
    loadAdminTab('shops');
  } catch (e) { showToast(e.message, 'error'); }
}

async function blockUser(id) {
  try {
    await PUT(`/users/admin/${id}/block`, {}, true);
    showToast('🚫 Корбар баст шуд');
    loadAdminTab('users');
  } catch (e) { showToast(e.message, 'error'); }
}

// SELLER DASHBOARD
async function sellerTab(id, btn) {
  document.querySelectorAll('#page-seller .chip').forEach(b => { b.classList.remove('active'); b.style.background = '#F3F4F6'; b.style.color = '#374151'; });
  if (btn) { btn.classList.add('active'); btn.style.background = '#1565C0'; btn.style.color = '#fff'; }
  const sc = document.getElementById('seller-content');
  sc.innerHTML = '<div class="loading"><div class="spinner"></div></div>';

  if (id === 'products') {
    try {
      const shop = currentUser?.shopId;
      if (!shop) { sc.innerHTML = '<div class="empty-state"><div>Дӯкон надоред</div></div>'; return; }
      const { products } = await GET(`/products?shop=${shop._id || shop}`, true);
      sc.innerHTML = `
        <button onclick="showAddProduct()" style="width:100%;background:linear-gradient(135deg,#FF5722,#FF7043);color:#fff;border:none;border-radius:14px;padding:12px;font-weight:800;font-size:14px;cursor:pointer;font-family:inherit;margin-bottom:14px">+ Маҳсулот илова кун</button>
        ${products.length ? `<div class="grid2">${products.map(p => `<div class="pcard">
          <div class="pcard-img">${p.emoji || '📦'}</div>
          <div class="pcard-body">
            <div class="pcard-name">${p.name}</div>
            <div class="pcard-price">${fmt(p.price)}</div>
            <div style="display:flex;gap:6px;margin-top:8px">
              <button onclick="editProduct('${p._id}')" style="flex:1;background:#EFF6FF;border:none;border-radius:8px;padding:6px;color:#3B82F6;font-weight:800;font-size:10px;cursor:pointer">✏️ Таҳрир</button>
              <button onclick="deleteProduct('${p._id}')" style="background:#FEE2E2;border:none;border-radius:8px;padding:6px 8px;color:#EF4444;font-weight:800;font-size:10px;cursor:pointer">🗑️</button>
            </div>
          </div>
        </div>`).join('')}</div>` : '<div class="empty-state"><div class="empty-ico">📦</div><div>Маҳсулот нест</div></div>'}`;
    } catch (e) { sc.innerHTML = '<div class="empty-state"><div>Бор нашуд</div></div>'; }
  } else if (id === 'orders') {
    try {
      const { orders } = await GET('/orders/shop', true);
      sc.innerHTML = orders.length ? orders.map(o => `<div style="background:#fff;border-radius:14px;padding:12px;margin-bottom:10px;box-shadow:0 2px 6px rgba(0,0,0,.05)">
        <div style="display:flex;justify-content:space-between;margin-bottom:4px"><span style="font-weight:800">${o.orderNumber}</span><span style="color:#FF5722;font-weight:800">${fmt(o.totalAmount)}</span></div>
        <div style="font-size:12px;color:#6B7280">${o.buyer?.name} • ${o.buyer?.phone}</div>
        <select onchange="updateOrderStatus('${o._id}',this.value)" style="margin-top:8px;width:100%;border:1.5px solid #E5E7EB;border-radius:8px;padding:7px;font-family:inherit;font-size:12px;outline:none">
          ${['ordered','processing','shipped','delivered'].map(s => `<option value="${s}" ${o.status===s?'selected':''}>${s}</option>`).join('')}
        </select>
      </div>`).join('') : '<div class="empty-state"><div class="empty-ico">📦</div><div>Фармоише нест</div></div>';
    } catch (e) { sc.innerHTML = '<div class="empty-state"><div>Бор нашуд</div></div>'; }
  }
}

async function updateOrderStatus(id, status) {
  try {
    await PUT(`/orders/${id}/status`, { status }, true);
    showToast('✅ Ҳолат тағйир ёфт');
  } catch (e) { showToast(e.message, 'error'); }
}

function showAddProduct() {
  const modal = document.getElementById('auth-modal');
  const content = document.getElementById('auth-modal-content');
  modal.classList.add('open');
  const cats = [['electronics','📱 Электроника'],['clothing','👗 Либос'],['home','🏠 Хона'],['toys','🧸 Бозичаҳо'],['auto','🚗 Авто'],['food','🍎 Ғизо'],['sports','⚽ Варзиш'],['other','📦 Дигар']];
  content.innerHTML = `
    <div class="modal-head">
      <div class="modal-title">📦 Маҳсулот илова кун</div>
      <button class="modal-close" onclick="document.getElementById('auth-modal').classList.remove('open')">✕</button>
    </div>
    <input id="p-name" class="form-input" placeholder="Номи маҳсулот">
    <textarea id="p-desc" class="form-input" placeholder="Тавсиф" rows="2" style="resize:none"></textarea>
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px">
      <input id="p-price" class="form-input" placeholder="Нарх (сом.)" type="number">
      <input id="p-orig" class="form-input" placeholder="Нархи аслӣ" type="number">
    </div>
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px">
      <input id="p-stock" class="form-input" placeholder="Захира" type="number">
      <input id="p-weight" class="form-input" placeholder="Вазн (кг)" type="number" step="0.1">
    </div>
    <select id="p-cat" class="form-input">
      ${cats.map(c => `<option value="${c[0]}">${c[1]}</option>`).join('')}
    </select>
    <input id="p-emoji" class="form-input" placeholder="Emoji (масалан: 📱)" value="📦">
    <button onclick="submitProduct()" class="btn-primary">✅ Илова кун</button>`;
}

async function submitProduct() {
  const data = {
    name: document.getElementById('p-name').value,
    description: document.getElementById('p-desc').value,
    price: Number(document.getElementById('p-price').value),
    originalPrice: Number(document.getElementById('p-orig').value) || undefined,
    stock: Number(document.getElementById('p-stock').value),
    weight: Number(document.getElementById('p-weight').value) || 0.5,
    category: document.getElementById('p-cat').value,
    emoji: document.getElementById('p-emoji').value || '📦',
  };
  if (!data.name || !data.price) { showToast('Ном ва нархро ворид кунед', 'error'); return; }
  try {
    await POST('/products', data, true);
    document.getElementById('auth-modal').classList.remove('open');
    showToast('✅ Маҳсулот илова шуд!');
    sellerTab('products', null);
  } catch (e) { showToast(e.message, 'error'); }
}

async function deleteProduct(id) {
  if (!confirm('Маҳсулотро нест кунед?')) return;
  try {
    await DELETE(`/products/${id}`, true);
    showToast('🗑️ Нест шуд');
    sellerTab('products', null);
  } catch (e) { showToast(e.message, 'error'); }
}
